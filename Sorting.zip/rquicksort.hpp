//include file for radix quicksort
#ifndef BOOST_RQUICKSORT_HPP
#define BOOST_RQUICKSORT_HPP
#include <cstring>
#include <cstdlib>
#include "detail/insertion.hpp"
#include <stdarg.h>
#include <deque>
namespace boost
{
	namespace detail
	{
        template<typename T>
        inline unsigned char qdigit(const T& a, int d)
        {
            return a.idstring_qs[d];
        }
        typedef char* cptr;
        template<>
        inline unsigned char qdigit<cptr>(const cptr& a, int d)
        {
            return a[d];
        }
        template<typename T>
        void rquicksort(T* ar, int l, int r, int bit)
        {
            if((r - l) <= 16) { insertion(ar, l, r); return;}
            register T* a = ar;
            register int i = l - 1, j = r, d = bit, v = qdigit(a[j], d);//speed increase with registers
            int p = i, q = j;
            while(i < j)
            {
                while(qdigit(a[++i], d) < v) ;
                while(v < qdigit(a[--j], d)) if(j == l) break;
                if(i > j) break;
                std::swap(a[i], a[j]);
                if(qdigit(a[i], d) == v) {++p; std::swap(a[p], a[i]);}
                if(qdigit(a[j], d) == v) {--q; std::swap(a[q], a[j]);}
            }
            if(p == q)
            {
                 if(v != '\0') rquicksort(a, l, r, d + 1);
                 return;
            }
            if(qdigit(a[i], d) < v) ++i;
            int k = l;
            for( ; k <= p; j--, k++) std::swap(a[k], a[j]);
            for(k = r; k >= q; i++, k--) std::swap(a[k], a[i]);
            rquicksort(a, l, j, d);
            if((i == r) && (qdigit(a[i], d) == v)) ++i;
            if(v != '\0') rquicksort(a, j + 1, i - 1, d + 1);
            rquicksort(a, i, r, d);
        }
        template<typename T>
        void rrquicksort(T* ar, int l, int r, int bit)
        {
            if((r - l) <= 16) { r_insertion(ar, l, r); return;}
            register T* a = ar;
            register int i = l - 1, j = r, d = bit, v = qdigit(a[j], d);//speed increase with registers
            int p = i, q = j;
            while(i < j)
            {
                while(v < qdigit(a[++i], d)) ;
                while(qdigit(a[--j], d) < v) if(j == l) break;
                if(i > j) break;
                std::swap(a[i], a[j]);
                if(qdigit(a[i], d) == v) {++p; std::swap(a[p], a[i]);}
                if(qdigit(a[j], d) == v) {--q; std::swap(a[q], a[j]);}
            }
            if(p == q)
            {
                 if(v != '\0') rrquicksort(a, l, r, d + 1);
                 return;
            }
            if(v < qdigit(a[i], d)) ++i;
            int k = l;
            for( ; k <= p; j--, k++) std::swap(a[k], a[j]);
            for(k = r; k >= q; i++, k--) std::swap(a[k], a[i]);
            rrquicksort(a, l, j, d);
            if((i == r) && (qdigit(a[i], d) == v)) ++i;
            if(v != '\0') rrquicksort(a, j + 1, i - 1, d + 1);
            rrquicksort(a, i, r, d);
        }
    }
	template<typename T>
	inline void radix_qsort(T* data, int size) //normal
	{
		detail::rquicksort(data, 0, size, 0);
	}
    template<typename T>
    inline void r_radix_qsort(T* data, int size) //reverse
    {
        detail::rrquicksort(data, 0, size, 0);
    }
    /////////////////////////user-defined functions
    namespace detail
	{
        template<typename T>
        void rquicksort(T* ar, int l, int r, int bit, unsigned char (*strfunc)(const T&, int), bool(*ltfunc)(const T&, const T&))
        {
            if((r - l) <= 16) { insertion(ar, l, r, ltfunc); return;}
            register T* a = ar;
            register int i = l - 1, j = r, d = bit, v = strfunc(a[j], d);
            int p = i, q = j;
            while(i < j)
            {
                while(strfunc(a[++i], d) < v) ;
                while(v < strfunc(a[--j], d)) if(j == l) break;
                if(i > j) break;
                std::swap(a[i], a[j]);
                if(strfunc(a[i], d) == v) {++p; std::swap(a[p], a[i]);}
                if(strfunc(a[j], d) == v) {--q; std::swap(a[q], a[j]);}
            }
            if(p == q)
            {
                 if(v != '\0') rquicksort(a, l, r, d + 1);
                 return;
            }
            if(strfunc(a[i], d) < v) ++i;
            int k = l;
            for( ; k <= p; j--, k++) std::swap(a[k], a[j]);
            for(k = r; k >= q; i++, k--) std::swap(a[k], a[i]);
            rquicksort(a, l, j, d);
            if((i == r) && (strfunc(a[i], d) == v)) ++i;
            if(v != '\0') rquicksort(a, j + 1, i - 1, d + 1);
            rquicksort(a, i, r, d);
        }
        template<typename T>
        void rrquicksort(T* ar, int l, int r, int bit, unsigned char (*strfunc)(const T&, int), bool(*ltfunc)(const T&, const T&))
        {
            if((r - l) <= 16) { r_insertion(ar, l, r, ltfunc); return;}
            register T* a = ar;
            register int i = l - 1, j = r, d = bit, v = strfunc(a[j], d);//speed increase with registers
            int p = i, q = j;
            while(i < j)
            {
                while(v < strfunc(a[++i], d)) ;
                while(strfunc(a[--j], d) < v) if(j == l) break;
                if(i > j) break;
                std::swap(a[i], a[j]);
                if(strfunc(a[i], d) == v) {++p; std::swap(a[p], a[i]);}
                if(strfunc(a[j], d) == v) {--q; std::swap(a[q], a[j]);}
            }
            if(p == q)
            {
                 if(v != '\0') rrquicksort(a, l, r, d + 1);
                 return;
            }
            if(v < strfunc(a[i], d)) ++i;
            int k = l;
            for( ; k <= p; j--, k++) std::swap(a[k], a[j]);
            for(k = r; k >= q; i++, k--) std::swap(a[k], a[i]);
            rrquicksort(a, l, j, d);
            if((i == r) && (strfunc(a[i], d) == v)) ++i;
            if(v != '\0') rrquicksort(a, j + 1, i - 1, d + 1);
            rrquicksort(a, i, r, d);
        }
    }
	template<typename T>
	inline void radix_qsort(T* data, int size, unsigned char (*strfunc)(const T&, int), bool(*ltfunc)(const T&, const T&)) //normal
	{
		detail::rquicksort(data, 0, size, 0, strfunc, ltfunc);
	}
    template<typename T>
    inline void r_radix_qsort(T* data, int size, unsigned char (*strfunc)(const T&, int), bool(*ltfunc)(const T&, const T&)) //reverse
    {
        detail::rrquicksort(data, 0, size, 0, strfunc, ltfunc);
    }
    //////////////////////////////////////////////////////////////////////////variable bytes
    template<typename T>
    inline void radix_qsort(T* a, int size, int startbyte)
    {
        detail::rquicksort(a, 0, size, startbyte);
    }
    template<typename T>
    inline void radix_qsort(T* a, int start, int size, int startbyte)
    {
        detail::rquicksort(a, start, size, startbyte);
    }
    template<typename T>
    inline void radix_qsort(T* a, int size, int startbyte, unsigned char(*strfunc)(const T&, int d), bool(*ltfunc)(const T&, const T&))
    {
        detail::rquicksort(a, 0, size, startbyte, strfunc, ltfunc);
    }
    template<typename T>
    inline void radix_qsort(T* a, int start, int size, int startbyte, unsigned char(*strfunc)(const T&, int d), bool(*ltfunc)(const T&, const T&))
    {
        detail::rquicksort(a, start, size, startbyte, strfunc, ltfunc);
    }
    ////////////////////////////////////////////////////////////stl iterator
    namespace detail
	{
        template<typename T>
        void rquicksort(typename std::deque<T>::iterator& a, int l, int r, int bit)
        {
            if((r - l) <= 16) { insertion<T>(a, l, r); return;}
            register int i = l - 1, j = r, d = bit, v = qdigit(*(a + j), d);//speed increase with registers
            int p = i, q = j;
            while(i < j)
            {
                while(qdigit(*(a + ++i), d) < v) ;
                while(v < qdigit(*(a + --j), d)) if(j == l) break;
                if(i > j) break;
                std::swap(*(a + i), *(a + j));
                if(qdigit(*(a + i), d) == v) {++p; std::swap(*(a + p), *(a + i));}
                if(qdigit(*(a + j), d) == v) {--q; std::swap(*(a + q), *(a + j));}
            }
            if(p == q)
            {
                 if(v != '\0') rquicksort<T>(a, l, r, d + 1);
                 return;
            }
            if(qdigit(*(a + i), d) < v) ++i;
            int k = l;
            for( ; k <= p; j--, k++) std::swap(*(a + k), *(a + j));
            for(k = r; k >= q; i++, k--) std::swap(*(a + k), *(a + i));
            rquicksort<T>(a, l, j, d);
            if((i == r) && (qdigit(*(a + i), d) == v)) ++i;
            if(v != '\0') rquicksort<T>(a, j + 1, i - 1, d + 1);
            rquicksort<T>(a, i, r, d);
        }
        template<typename T>
        void rrquicksort(typename std::deque<T>::iterator& a, int l, int r, int bit)
        {
            if((r - l) <= 16) { r_insertion<T>(a, l, r); return;}
            register int i = l - 1, j = r, d = bit, v = qdigit(*(a + j), d);//speed increase with registers
            int p = i, q = j;
            while(i < j)
            {
                while(v < qdigit(*(a + ++i), d)) ;
                while(qdigit(*(a + --j), d) < v) if(j == l) break;
                if(i > j) break;
                std::swap(*(a + i), *(a + j));
                if(qdigit(*(a + i), d) == v) {++p; std::swap(*(a + p), *(a + i));}
                if(qdigit(*(a + j), d) == v) {--q; std::swap(*(a + q), *(a + j));}
            }
            if(p == q)
            {
                 if(v != '\0') rrquicksort<T>(a, l, r, d + 1);
                 return;
            }
            if(v < qdigit(*(a + i), d)) ++i;
            int k = l;
            for( ; k <= p; j--, k++) std::swap(*(a + k), *(a + j));
            for(k = r; k >= q; i++, k--) std::swap(*(a + k), *(a + i));
            rrquicksort<T>(a, l, j, d);
            if((i == r) && (qdigit(*(a + i), d) == v)) ++i;
            if(v != '\0') rrquicksort<T>(a, j + 1, i - 1, d + 1);
            rrquicksort<T>(a, i, r, d);
        }
    }
	template<typename T>
	inline void radix_qsort(typename std::deque<T>::iterator& data, int size) //normal
	{
		detail::rquicksort<T>(data, 0, size, 0);
	}
    template<typename T>
    inline void r_radix_qsort(typename std::deque<T>::iterator& data, int size) //reverse
    {
        detail::rrquicksort<T>(data, 0, size, 0);
    }
    /////////////////////////user-defined functions
    namespace detail
	{
        template<typename T>
        void rquicksort(typename std::deque<T>::iterator& a, int l, int r, int bit, unsigned char (*strfunc)(const T&, int), bool(*ltfunc)(const T&, const T&))
        {
            if((r - l) <= 16) { insertion<T>(a, l, r, ltfunc); return;}
            register int i = l - 1, j = r, d = bit, v = strfunc(*(a + j), d);
            int p = i, q = j;
            while(i < j)
            {
                while(strfunc(*(a + ++i), d) < v) ;
                while(v < strfunc(*(a + --j), d)) if(j == l) break;
                if(i > j) break;
                std::swap(*(a + i), *(a + j));
                if(strfunc(*(a + i), d) == v) {++p; std::swap(*(a + p), *(a + i));}
                if(strfunc(*(a + j), d) == v) {--q; std::swap(*(a + q), *(a + j));}
            }
            if(p == q)
            {
                 if(v != '\0') rquicksort<T>(a, l, r, d + 1);
                 return;
            }
            if(strfunc(*(a + i), d) < v) ++i;
            int k = l;
            for( ; k <= p; j--, k++) std::swap(*(a + k), *(a + j));
            for(k = r; k >= q; i++, k--) std::swap(*(a + k), *(a + i));
            rquicksort<T>(a, l, j, d);
            if((i == r) && (strfunc(*(a + i), d) == v)) ++i;
            if(v != '\0') rquicksort<T>(a, j + 1, i - 1, d + 1);
            rquicksort<T>(a, i, r, d);
        }
        template<typename T>
        void rrquicksort(typename std::deque<T>::iterator& a, int l, int r, int bit, unsigned char (*strfunc)(const T&, int), bool(*ltfunc)(const T&, const T&))
        {
            if((r - l) <= 16) { r_insertion<T>(a, l, r, ltfunc); return;}
            register int i = l - 1, j = r, d = bit, v = strfunc(*(a + j), d);//speed increase with registers
            int p = i, q = j;
            while(i < j)
            {
                while(v < strfunc(*(a + ++i), d)) ;
                while(strfunc(*(a + --j), d) < v) if(j == l) break;
                if(i > j) break;
                std::swap(*(a + i), *(a + j));
                if(strfunc(*(a + i), d) == v) {++p; std::swap(*(a + p), *(a + i));}
                if(strfunc(*(a + j), d) == v) {--q; std::swap(*(a + q), *(a + j));}
            }
            if(p == q)
            {
                 if(v != '\0') rrquicksort<T>(a, l, r, d + 1);
                 return;
            }
            if(v < strfunc(*(a + i), d)) ++i;
            int k = l;
            for( ; k <= p; j--, k++) std::swap(*(a + k), *(a + j));
            for(k = r; k >= q; i++, k--) std::swap(*(a + k), *(a + i));
            rrquicksort<T>(a, l, j, d);
            if((i == r) && (strfunc(*(a + i), d) == v)) ++i;
            if(v != '\0') rrquicksort<T>(a, j + 1, i - 1, d + 1);
            rrquicksort<T>(a, i, r, d);
        }
    }
	template<typename T>
	inline void radix_qsort(typename std::deque<T>::iterator& data, int size, unsigned char (*strfunc)(const T&, int), bool(*ltfunc)(const T&, const T&)) //normal
	{
		detail::rquicksort<T>(data, 0, size, 0, strfunc, ltfunc);
	}
    template<typename T>
    inline void r_radix_qsort(typename std::deque<T>::iterator& data, int size, unsigned char (*strfunc)(const T&, int), bool(*ltfunc)(const T&, const T&)) //reverse
    {
        detail::rrquicksort<T>(data, 0, size, 0, strfunc, ltfunc);
    }
    //////////////////////////////////////////////////////////////////////////variable bytes
    template<typename T>
    inline void radix_qsort(typename std::deque<T>::iterator& a, int size, int startbyte)
    {
        detail::rquicksort<T>(a, 0, size, startbyte);
    }
    template<typename T>
    inline void radix_qsort(typename std::deque<T>::iterator& a, int start, int size, int startbyte)
    {
        detail::rquicksort<T>(a, start, size, startbyte);
    }
     template<typename T>
    inline void radix_qsort(typename std::deque<T>::iterator& a, int size, int startbyte, unsigned char(*strfunc)(const T&, int d), bool(*ltfunc)(const T&, const T&))
    {
        detail::rquicksort<T>(a, 0, size, startbyte, strfunc, ltfunc);
    }
    template<typename T>
    inline void radix_qsort(typename std::deque<T>::iterator& a, int start, int size, int startbyte, unsigned char(*strfunc)(const T&, int d), bool(*ltfunc)(const T&, const T&))
    {
        detail::rquicksort<T>(a, start, size, startbyte, strfunc, ltfunc);
    }

    int create_id_string(char* fmt, char* dest, ...)
    {
        va_list ap;
        char* p;
        int n = 0;
        int itemp;
        double dtemp;
        int length = 0;
        long long dwval;
        unsigned char*ctemp;
        unsigned char ctemp2[30];
        va_start(ap, dest);
        for(p = fmt; *p; p++)
        {
            if(*p != '%')
            {
                dest[n++] = *p;
                continue;
            }
            switch(*++p)
            {
            case 'd': case 'D': case 'i': case 'I':
                itemp = va_arg(ap, int);
                itoa(itemp, (char*)ctemp2, 16);
                    for(int x = 0; ctemp2[x]; x++)
                    {
                        dest[n++] = ctemp2[x];
                    }
                    break;
            case 's': case 'S':
                    for(ctemp = va_arg(ap, unsigned char*); *ctemp;) dest[n++] = *ctemp++;
                    break;
            case 'e': case 'E': case 'g': case 'G':
                dtemp = va_arg(ap, double);
                dwval = *((long long*)&dtemp);
                _i64toa(dwval, (char*)ctemp2, 16);
                for(int x = 0; ctemp2[x]; x++)
                {
                    dest[n++] = ctemp2[x];
                }
                break;
            default:
                dest[n++] = *p;
                break;
            }
        }
        dest[n++] = '\0';
        va_end(ap);
        return n + 1; //1 compenstates for zero index array
    }
}
#endif
