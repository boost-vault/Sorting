#ifndef BOOST_EXTERNAL_BASE_HPP
#define BOOST_EXTERNAL_BASE_HPP
#include <fstream>
#include "radix.hpp"
#include "rquicksort.hpp"
#include <algorithm>
namespace boost
{
    namespace detail
    {
        template<class T>
        void chunkfile_r(FILE* p, int l, int r, int parts, int& numfile, int* nums)
        {
            if(parts < 16)
            {
                chunkfile_r<T>(p, l, (l + r) >> 1, parts << 1, numfile, nums); //divide up into sixteen
                chunkfile_r<T>(p, ((l + r) >> 1) + 1, r, parts << 1, numfile, nums);
            }
            T* data = new T[(r - l) + 1];
            fseek(p, l, SEEK_SET);
            fread(data, sizeof(T), (r - l) + 1, p);
            boost::radix_sort(data, (l - r) + 1);
            fseek(p, l, SEEK_SET);
            fwrite(data, sizeof(T), (l - r) + 1, p);
            nums[numfile++] = r;
            delete[] data;
        }
    }       
    template<class T>
    inline void ex_radix_sort(FILE* p, long long size)
    {
         int nums[16]; //data with number written to it
         int filecounter = 0;
         FILE* temp = tmpfile();
         detail::chunkfile_r<T>(p, 0, size, 1, filecounter, nums);
         long long count[16] = {nums[0], nums[1], nums[2], nums[3], nums[4], nums[5], nums[6], nums[7], nums[8], nums[9], nums[10], nums[11], nums[12], nums[13], nums[14], nums[15]};
         for(long long x = 0; x < size; x++)
         {
                T max;
                for(int y = 1; y < 15; y++)
                {
                    if(count[y] != count[y + 1])
                    {
                        fseek(p, count[y]++, SEEK_SET);
                        T v;
                        fread(&v, sizeof(T), 1, p);
                        if(v > max) max = v;
                    }
                }
                if(count[15] != size)
                {
                    fseek(p, count[15]++, SEEK_SET);
                    T v;
                    fread(&v, sizeof(T), 1, p);
                    if(v > max) max = v;
                }
                fseek(temp, x, SEEK_SET);
                fwrite(&max, sizeof(T), 1, temp);
         }
         for(long long x = 0; x < size; x++)
         {
                T tmp;
                fread(&tmp, sizeof(T), 1, temp);
                fwrite(&tmp, sizeof(T), 1, p);
         }
    }              
}
#endif
