#ifndef BOOST_DETAIL_INSERTION_HPP
#define BOOST_DETAIL_INSERTION_HPP
#include <algorithm>
#include <cstring>
#include <deque>
namespace boost
{
namespace detail
{
template<class T>
void insertion(T* ar, int l, int r)
{
	register T* a = ar;
	register int i;
	for(i = r; i > l; i--) if(a[i] < a[i - 1]) std::swap<T>(a[i], a[i - 1]);
	for(i = l + 2; i <= r; i++)
	{
		register int j = i; T v = a[i];
		while(v < a[j - 1])
		{
			a[j] = a[j - 1];
			--j;
		}
		a[j] = v;
	}
}

template<>
void insertion<char*>(char** ar, int l, int r)
{
	register char** a = ar;
	register int i;
	for(i = r; i > l; i--) if(strcmp(a[i], a[i - 1]) & 0x80000000) std::swap<char*>(a[i], a[i - 1]);
	for(i = l + 2; i <= r; i++)
	{
		register int j = i; register char* v = a[i];
		while(strcmp(v, a[j - 1]) & 0x80000000)
		{
			a[j] = a[j - 1];
			--j;
		}
		a[j] = v;
	}
}
template<class T>
void r_insertion(T* ar, int l, int r)
{
	register T* a = ar;
	register int i;
	for(i = r; i > l; i--) if(a[i - 1] <  a[i]) std::swap<T>(a[i], a[i - 1]);
	for(i = l + 2; i <= r; i++)
	{
		register int j = i; T v = a[i];
		while(a[j - 1] < v)
		{
			a[j] = a[j - 1];
			--j;
		}
		a[j] = v;
	}
}
template<>
void r_insertion<char*>(char** ar, int l, int r)
{
	register char** a = ar;
	register int i;
	for(i = r; i > l; i--) if(strcmp(a[i - 1], a[i]) & 0x80000000) std::swap<char*>(a[i], a[i - 1]);
	for(i = l + 2; i <= r; i++)
	{
		register int j = i; char* v = a[i];
		while(strcmp(a[j - 1], v) & 0x80000000)
		{
			a[j] = a[j - 1];
			--j;
		}
		a[j] = v;
	}
}
//////////////user-defined
template<class T>
void insertion(T* ar, int l, int r, bool(*ltfunc)(const T&, const T&))
{
	register T* a = ar;
	register int i;
	for(i = r; i > l; i--) if(lt(a[i], a[i - 1])) std::swap<T>(a[i], a[i - 1]);
	for(i = l + 2; i <= r; i++)
	{
		register int j = i; T v = a[i];
		while(lt(v, a[j - 1]))
		{
			a[j] = a[j - 1];
			--j;
		}
		a[j] = v;
	}
}
template<class T>
void r_insertion(T* ar, int l, int r, bool(*ltfunc)(const T&, const T&))
{
	register T* a = ar;
	register int i;
	for(i = r; i > l; i--) if(lt(a[i - 1], a[i])) std::swap<T>(a[i], a[i - 1]);
	for(i = l + 2; i <= r; i++)
	{
		register int j = i; T v = a[i];
		while(lt(a[j - 1], v))
		{
			a[j] = a[j - 1];
			--j;
		}
		a[j] = v;
	}
}
///////////////////////////////////////////////////////////////////////standard library sorters
template<class T>
void insertion(typename std::deque<T>::iterator& a, int l, int r)
{
	register int i;
	for(i = r; i > l; i--) if(*(a + i) < *(a + i - 1)) std::swap<T>(*(a + i), *(a + i - 1));
	for(i = l + 2; i <= r; i++)
	{
		register int j = i; T v = *(a + i);
		while(v < *(a + j - 1))
		{
			*(a + j) = *(a + j - 1);
			--j;
		}
		*(a + j) = v;
	}
}

template<>
void insertion<char*>(typename std::deque<char*>::iterator& a, int l, int r)
{
	register int i;
	for(i = r; i > l; i--) if(strcmp(*(a + i), *(a + i - 1)) & 0x80000000) std::swap<char*>(*(a + i), *(a + i - 1));
	for(i = l + 2; i <= r; i++)
	{
		register int j = i; register char* v = *(a + i);
		while(strcmp(v, *(a + j - 1)) & 0x80000000)
		{
			*(a + j) = *(a + j - 1);
			--j;
		}
		*(a + j) = v;
	}
}
template<class T>
void r_insertion(typename std::deque<T>::iterator& a, int l, int r)
{
	register int i;
	for(i = r; i > l; i--) if(*(a + i - 1) <  *(a + i)) std::swap<T>(*(a + i), *(a + i - 1));
	for(i = l + 2; i <= r; i++)
	{
		register int j = i; T v = *(a + i);
		while(*(a + j - 1) < v)
		{
			*(a + j) = *(a + j - 1);
			--j;
		}
		*(a + j) = v;
	}
}
template<>
void r_insertion<char*>(typename std::deque<char*>::iterator& a, int l, int r)
{
	register int i;
	for(i = r; i > l; i--) if(strcmp(*(a + i - 1), *(a + i)) & 0x80000000) std::swap<char*>(*(a + i), *(a + i - 1));
	for(i = l + 2; i <= r; i++)
	{
		register int j = i; char* v = *(a + i);
		while(strcmp(*(a + j - 1), v) & 0x80000000)
		{
			*(a + j) = *(a + j - 1);
			--j;
		}
		*(a + j) = v;
	}
}
//////////////user-defined
template<class T>
void insertion(typename std::deque<T>::iterator& a, int l, int r, bool(*ltfunc)(const T&, const T&))
{
	register int i;
	for(i = r; i > l; i--) if(lt(*(a + i), *(a + i - 1))) std::swap<T>(*(a + i), *(a + i - 1));
	for(i = l + 2; i <= r; i++)
	{
		register int j = i; T v = *(a + i);
		while(lt(v, *(a + j - 1)))
		{
			*(a + j) = *(a + j - 1);
			--j;
		}
		*(a + j) = v;
	}
}
template<class T>
void r_insertion(typename std::deque<T>::iterator& a, int l, int r, bool(*ltfunc)(const T&, const T&))
{
	register int i;
	for(i = r; i > l; i--) if(lt(*(a + i - 1), *(a + i))) std::swap<T>(*(a + i), *(a + i - 1));
	for(i = l + 2; i <= r; i++)
	{
		register int j = i; T v = *(a + i);
		while(lt(*(a + j - 1), v))
		{
			*(a + j) = *(a + j - 1);
			--j;
		}
		*(a + j) = v;
	}
}
}
}
#endif
