//file for timer class
#include <ctime>
using namespace std;
class MTimer
{
      clock_t thetime;
      public:
      MTimer() : thetime(0)
      {}
      void start()
      {
           thetime = clock();
      }
      clock_t stop()
      {
              return clock() - thetime;
      }
};
