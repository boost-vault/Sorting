#include <cstdlib>
#include <iostream>
#include "Timer.hpp"
#include "radix.hpp"
#include "mkquicksort.hpp"
#include "rquicksort.hpp"
#include <algorithm>
using namespace std;
using namespace std;
int mkqsortfnc();
int rqsortfnc();
int rsortfnc();
int main(int argc, char *argv[])
{
    cout << "An example program comparing the speed of the radix sorts to that of std::sort" << endl;
    mkqsortfnc();
    rsortfnc();
    rqsortfnc();
    system("PAUSE");
    return 0;
}
const int maxn = 5000000;
const int term = -1; //never returned by rand
void randintarray(int* a, int num)
{
    for(int x = 0; x < num; x++)
    {
        a[x] = rand();
    }
    a[num] = term;
}
typedef bool(*cmpfunc)(int*, int*);
bool compfunc(int* a, int* b)
{
    for(; (*a != term) && (*b != term); a++, b++)
    {
        if(*a < *b) return true;
        else if(*b < *a) return false;
    }
    return false;
}

int* ar[maxn];
int mkqsortfnc()
{
    cout << "Sorting " << maxn <<" million integer arrays of length 20" << endl;
    cout << "Allocating and randomizing arrays" << endl;
    int stdsort, mkqsort;
    for(int x = 0; x < maxn; x++)
    {
        ar[x] = new int[21];
        randintarray(ar[x], 20);
    }
    MTimer timer;
    cout << "Starting Multikey quicksort" << endl;
    timer.start();
    boost::mk_qsort<int**, int, int*>(ar, maxn - 1, 0);
    cout << "Multikey quicksort took " << (mkqsort = timer.stop()) << " milliseconds" << endl;
    cout << "Re-randomizing arrays" << endl;
    for(int x = 0; x < maxn; x++)
    {
        randintarray(ar[x], 20);
    }
    cout << "Starting std::sort" << endl;
    timer.start();
    std::sort<int**, cmpfunc>(ar, ar + maxn, &compfunc);
    cout << "std::sort took " << (stdsort = timer.stop()) << " milliseconds" << endl;
    cout << "Multikey quicksort is " << (double)stdsort / mkqsort << " times faster than std::sort" << endl;
    cout << "De-allocating arrays" << endl;
    for(int x = 0; x < maxn; x++)
    {
        delete[] ar[x];
    }
	return 0;
}
float af[maxn];
int ai[maxn];
int rsortfnc()
{
    MTimer timer;
    cout << "Comparison of timings between std::sort and radixsort on floats and integers\n"
         << "These results are both on random arrays, and the units are milliseconds\n";
    cout << "Sorting " << maxn << " floats" << endl;
    int stdsort, radixsort;
    cout << "Randomizing arrays" << endl;
    for(int x = 0; x < maxn; x++)
    {
        af[x] = ((float)rand() / rand()) * (rand() % 2) ? -1 : 1;
    }
    cout << "Starting radixsort" << endl;
    timer.start();
    boost::radix_sort<float>(af, maxn);
    cout << "Radix Sort: " << (radixsort = timer.stop()) << endl;
    cout << "Re-randomizing arrays" << endl;
    for(int x = 0; x < maxn; x++)
    {
        af[x] = (float)rand() / rand();
    }
    cout << "Starting std::sort" << endl;
    timer.start();
    std::sort<float*>(af, &af[maxn]);
    cout << "std::sort: " << (stdsort = timer.stop()) << endl;
    cout << "Radixsort is " << ((double)stdsort / radixsort) << " times faster than std::sort sorting floats" << endl;
     cout << "Sorting " << maxn << " ints" << endl;
    cout << "Randomizing arrays" << endl;
    for(int x = 0; x < maxn; x++)
    {
        ai[x] = rand();
    }
    timer.start();
    boost::radix_sort<int>(ai, maxn);
    cout << "Radix Sort: " << (radixsort = timer.stop()) << endl;
    cout << "Re-randomizing arrays" << endl;
    for(int x = 0; x < maxn; x++)
    {
        ai[x] = rand();
    }
    cout << "Starting std::sort" << endl;
    timer.start();
    std::sort<int*>(ai, &ai[maxn]);
    cout << "std::sort: " << (stdsort = timer.stop()) << endl;
    cout << "Radixsort is " << ((double)stdsort / radixsort) << " times faster than std::sort sorting ints" << endl;
    return 0;
}
typedef int(*strfnc)(const char*, const char*);
int strfunc(const char* x, const char* y)
{
    return strcmp(x, y) & 0x80000000;
}
inline void rstring(char* a, int num)
{
    for(int x = 0; x < num; x++, a++)
    {
        *a = (rand() % 26) + 'a';
    }
    *a = '\0';
}
char* strs[maxn];
int rqsortfnc()
{
    cout << "Sorting " << maxn << " strings 30 characters long using radix quicksort" << endl;
    cout << "Initializing and randomizing strings" << endl;
    for(int x = 0; x < maxn; x++)
    {
        strs[x] = new char[31];
        rstring(strs[x], 30);
    }
    int stdsort, radixsort;
    MTimer timer;
    cout << "Starting Radix quicksort" << endl;
    timer.start();
    boost::radix_qsort<char*>(strs, maxn - 1);
    cout << "radix_qsort: " << (radixsort = timer.stop()) << " milliseconds" << endl;
    cout << "Re-randomizing strings" << endl;
    for(int x = 0; x < maxn; x++)
    {
        rstring(strs[x], 30);
    }
    cout << "Starting std::sort" << endl;
    timer.start();
    std::sort<char**, strfnc>(strs, &strs[maxn - 1], &strfunc);
    cout << "std::sort: " << (stdsort = timer.stop()) << " milliseconds" << endl;
    cout << "Radixsort is " <<  (double) stdsort / radixsort << " times faster than std::sort" << endl;
    cout << "De-allocating arrays" << endl;
    for(int x = 0; x < maxn; x++)
    {
        delete[] strs[x];
    }
	return 0;
}

