//include file for radix sorts
#ifndef BOOST_RADIX_SORT_HPP
#define BOOST_RADIX_SORT_HPP
#include <algorithm> //for swap
#include <deque>
inline void zerocarray(unsigned int* a)
{
    unsigned int* end = a + 256;
    for(; a != end; a++)
    {
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0; //major loop unrolling
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0; //major loop unrolling
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0; //major loop unrolling
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a++ = 0;
        *a = 0; //major loop unrolling
        }
}
namespace boost
{
namespace detail
{
          template<class T>
          struct dumb_ptr //needs to always be deleted, but must have no extra cost associated with it
          {
                 T* ptr;
                 dumb_ptr(T* _ptr) : ptr(_ptr)
                 {}
                 ~dumb_ptr()
                 {
                     delete ptr;
                 }
                 operator T*()
                 {
                     return ptr;
                 }
                 T& operator[](int num)
                 {
                     return ptr[num];
                 }
};
	typedef long int32;
	typedef unsigned long uint32;
	typedef float real32;
	typedef double real64;
	typedef unsigned char uint8;
	typedef const char *cpointer;
	inline uint32 _0(uint32 x)
	{
		return x & 0x7ff;
	}
	inline uint32 _1(uint32 x)
	{
		return x >> 11 & 0x7ff;
	}
	inline uint32 _2(uint32 x)
	{
		return x >> 22;
	}
// ================================================================================================
// flip a float for sorting
//  finds SIGN of fp number.
//  if it's 1 (negative float), it flips all bits
//  if it's 0 (positive float), it flips the sign only
// ================================================================================================
inline uint32 FloatFlip(uint32 f)
{
	return f ^ (-int32(f >> 31) | 0x80000000);
}
inline void FloatFlipX(uint32 &f)
{
	f ^= (-int32(f >> 31) | 0x80000000);
}
// ================================================================================================
// flip a float back (invert FloatFlip)
//  signed was flipped from above, so:
//  if sign is 1 (negative), it flips the sign bit back
//  if sign is 0 (positive), it flips all bits back
// ================================================================================================
inline uint32 IFloatFlip(uint32 f)
{
	return f ^ (((f >> 31) - 1) | 0x80000000);
}
void floatradix(real32 *farray, real32 *sorted, uint32 elements)
{
	uint32 i;
	uint32 *sort = (uint32*)sorted;
	uint32 *array = (uint32*)farray;
	const uint32 kHist = 2048;
	uint32 b0[kHist * 3];
    uint32 tkHist = kHist * 3; //this is so I can avoid a multiply instruction in the loop below
    i = 0;
	uint32 *b1 = b0 + kHist;
	uint32 *b2 = b1 + kHist;
	for (; i < tkHist; i++) {
		b0[i] = 0;
	}
    i = 0;
	for (; i < elements; i++) {
		
		uint32 fi = FloatFlip((uint32&)array[i]);

		++b0[_0(fi)];
		++b1[_1(fi)];
		++b2[_2(fi)];
	}
	{
        i = 0;
		uint32 sum0 = 0, sum1 = 0, sum2 = 0;
		uint32 tsum;
		for (; i < kHist; i++) {

			tsum = b0[i] + sum0;
			b0[i] = sum0 - 1;
			sum0 = tsum;

			tsum = b1[i] + sum1;
			b1[i] = sum1 - 1;
			sum1 = tsum;

			tsum = b2[i] + sum2;
			b2[i] = sum2 - 1;
			sum2 = tsum;
		}
	}
	for (i = 0; i < elements; i++) {

		uint32 fi = array[i];
		FloatFlipX(fi);
		uint32 pos = _0(fi);
		
		sort[++b0[pos]] = fi;
	}

	for (i = 0; i < elements; i++) {
		uint32 si = sort[i];
		uint32 pos = _1(si);
		array[++b1[pos]] = si;
	}

	for (i = 0; i < elements; i++) {
		uint32 ai = array[i];
		uint32 pos = _2(ai);
		sort[++b2[pos]] = IFloatFlip(ai);
	}
}
template<class T>
inline unsigned char rdigit( T& num, std::size_t d)
{
    return num[d];
}
template<>
inline unsigned char rdigit( int& num, size_t d)
{
    return (unsigned char)(num >> (d << 3));
}
template<>
inline unsigned char rdigit<long>( long& num, size_t d)
{
    return (unsigned char)(num >> (d << 3));
}
template<>
inline unsigned char rdigit<long long>( long long& num, size_t d)
{
    return (unsigned char)(num >> (d << 3));
}
template<>
inline unsigned char rdigit<char>(char& num, std::size_t d)
{
    return (unsigned char)num;
}
template<>
inline unsigned char rdigit<short>( short& num, std::size_t d)
{
    return (unsigned char)(num >> (d << 3));
}
template <class T>
void _radix(short bitsOffset, T* source, T* dest, std::size_t N)
{
		unsigned int count[256];
        unsigned int *cp;
        unsigned int s, c;
		T *sp = source;
		T* end = sp + N;
        zerocarray(count);
        for (; sp != end; sp++) {
                cp = count + rdigit(*sp, bitsOffset);
                ++(*cp);
        }
unsigned int* ep;
        cp = count;
        ep = count + 256;
        s = 0;
        for (; cp != ep; cp++) {
                c = *cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
        }
        sp = source;
        for (; sp != end; ++sp) {
                cp = count + rdigit(*sp, bitsOffset);
                dest[*cp] = *sp;
                ++(*cp);
		}
}
template <class T>
void _radix(short bitsOffset, T* source, T* dest, T* end)
{
		unsigned int count[256];
        unsigned int *cp;
        unsigned int s, c, i;
		T *sp = source;
        zerocarray(count);
        for (; sp != end; sp++) {
                cp = count + rdigit(*sp, bitsOffset);
                ++(*cp);
        }
        unsigned int* ep;
        cp = count;
        ep = count + 256;
        s = 0;
        for (; cp != ep; cp++) {
                c = *cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
        }
        sp = source;
        for(; sp != end; sp++) {
                cp = count + rdigit(*sp, bitsOffset);
                dest[*cp] = *sp;
                ++(*cp);
		}
}
template<class T>
inline void _radixc(short bitsOffset, T* source, T* dest, int N)
{
    T* s = source;
    T* d = dest;
    _radix<T>(bitsOffset, s, d, N);
    for(int x = 0; x < N; source++, dest++, x++)
    {
        *source = *dest;
    }
}
}
template<class T>
inline void radix_sort(T* array, int size, int bytes)
{   
    if(bytes > 20)
    {
        if(bytes % 2 == 0)
        {
            radix_sort(array, size, bytes - 1, bytes); //do the least array copy possible
            radix_sort(array, size, bytes - 2);
        }
        else
        {
            radix_sort(array, size, bytes, bytes);
            radix_sort(array, size, bytes - 1);
        }
        return;
    }
    detail::dumb_ptr<T> temp(new T[size]);
    if(bytes % 2 == 0)
    {
    if(bytes >= 2)
    {
	    detail::_radix<T>(0, array, temp, size);
	    detail::_radix<T>(1, temp, array, size);
    }
    if(bytes >= 4)
    {
        detail::_radix<T>(2, array, temp, size);
	    detail::_radix<T>(3, temp, array, size);
    }
    if(bytes >= 6)
    {
        detail::_radix<T>(4, array, temp, size);
	    detail::_radix<T>(5, temp, array, size);
    }
    if(bytes >= 8)
    {
	    detail::_radix<T>(6, array, temp, size);
	    detail::_radix<T>(7, temp, array, size);
    }
    if(bytes >= 10)
    {
        detail::_radix<T>(8, array, temp, size);
	    detail::_radix<T>(9, temp, array, size);
    }
    if(bytes >= 12)
    {
	    detail::_radix<T>(10, array, temp, size);
	    detail::_radix<T>(11, temp, array, size);
    }
    if(bytes >= 14)
    {
        detail::_radix<T>(12, array, temp, size);
	    detail::_radix<T>(13, temp, array, size);
    }
    if(bytes >= 16)
    {
       	detail::_radix<T>(14, array, temp, size);
	    detail::_radix<T>(15, temp, array, size);
    }
    if(bytes >= 18)
    {
        detail::_radix<T>(16, array, temp, size);
	    detail::_radix<T>(17, temp, array, size);
    }
    if(bytes == 20)
    {
        detail::_radix<T>(18, array, temp, size);
	    detail::_radix<T>(19, temp, array, size);
    }
    }
    else
    {
    for(int x = 0; x < bytes; x++)
        detail::_radixc<T>(x, array, temp, size);
    }
}
template<class T>
inline void radix_sort(T* array, int size)
{
    radix_sort<T>(array, size, sizeof(T));
}
template<>
inline void radix_sort<float>(float* array, int size)
{
    detail::dumb_ptr<float> temp = detail::dumb_ptr<float>(new float[size]);
	detail::floatradix(array, temp.ptr, size);
	for(int x = 0; x < size; x++)
	{
		array[x] = temp[x];
	}
}
template<class T>
inline void r_radix_sort(T* array, int size)
{
    radix_sort<T>(array, size);
    for(int x = 0; x < size >> 1; x++)
    {
        std::swap(array[x], array[size - x - 1]);
    }
}
template<class T>
inline void r_radix_sort(T* array, int size, int bytes)
{
    radix_sort<T>(array, size, bytes);
    for(int x = 0; x < size >> 1; x++)
    {
        std::swap(array[x], array[size - x - 1]);
    }
}
////////////////////////////////user-defined
namespace detail
{
template <class T>
void _radix(short bitsOffset, T* source, T* dest, int N, unsigned char(*bytef)(const T&, int))
{
		const int max = 256;
		unsigned int count[max];
        unsigned int *cp;
        unsigned int s, c, i;
		T* sp;
		T* end = sp + N;
        sp = source;
        zerocarray(count);
        for (; sp != end; sp++) {
                cp = count + bytef(*sp, bitsOffset);
                ++(*cp);
        }
unsigned int* ep;
        cp = count;
        ep = count + 256;
        s = 0;
        for (; cp != ep; cp++) {
                c = *cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
        }
        sp = source;
        for (; sp != end; sp++) {
                cp = count + bytef(*sp, bitsOffset);
                dest[*cp] = *sp;
                ++(*cp);
		}
}
template <class T>
void _radix(short bitsOffset, T* source, T* dest, T* end, unsigned char(*bytef)(const T&, int))
{
		const int max = 256;
		unsigned int count[max];
        unsigned int *cp;
        unsigned int s, c;
		T* sp;
        sp = source;
        zerocarray(count);
        for (; sp != end; sp++) {
                cp = count + bytef(*sp, bitsOffset);
                ++(*cp);
        }
unsigned int* ep;
        cp = count;
        ep = count + 256;
        s = 0;
        for (; cp != ep; cp++) {
                c = *cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
        }
        sp = source;
        for (; sp != end; sp++) {
                cp = count + bytef(*sp, bitsOffset);
                dest[*cp] = *sp;
                ++(*cp);
		}
}
template<class T>
inline void _radixc(short bitsOffset, T* source, T* dest, int N, unsigned char(*bytef)(const T&, int))
{
    _radix<T>(bitsOffset, source, dest, N, bytef);
    for(int x = 0; x < N; source++, dest++, x++)
    {
        *source = *dest;
    }
}
}
template<class T>
inline void radix_sort(T* a, int size, int sbyte, int ebyte)
{
    T* temp = new T[size];
    for(int x = sbyte; x < ebyte; x++)
    {
        detail::_radixc<T>(x, a, temp, size);
    }
}
template<class T>
inline void r_radix_sort(T* a, int size, int sbyte, int ebyte)
{
    T* temp = new T[size];
    for(int x = sbyte; x < sbyte; x++)
    {
        detail::_radixc<T>(x, a, temp, size);
    }
    for(int x = 0; x < size >> 1; x++)
        std::swap(a[x], a[size - x - 1]);
}
template<class T>
inline void radix_sort(T* a, int size, int sbyte, int ebyte, unsigned char(*bytef)(const T&, int))
{
    T* temp = new T[size];
    for(int x = sbyte; x < ebyte; x++)
    {
        detail::_radixc<T>(x, a, temp, size, bytef);
    }
}
template<class T>
inline void r_radix_sort(T* a, int size, int sbyte, int ebyte, unsigned char(*bytef)(const T&, int))
{
    T* temp = new T[size];
    for(int x = sbyte; x < ebyte; x++)
    {
        detail::_radixc<T>(x, a, temp, size, bytef);
    }
    for(int x = 0; x < size >> 1; x++)
        std::swap(a[x], a[size - x - 1]);
}
template<class T>
inline void radix_sort(T* array, int size, int bytes, unsigned char(*bytef)(const T&, int))
{
    if(bytes > 20)
    {
        if(bytes % 2 == 0)
        {
            radix_sort(array, size, bytes - 1, bytes, bytef); //do the least array copy possible
            radix_sort(array, size, bytes - 2, bytef);
        }
        else
        {
            radix_sort(array, size, bytes, bytes, bytef);
            radix_sort(array, size, bytes - 1, bytef);
        }
        return;
    }
    detail::dumb_ptr<T> temp(new T[size]);
    if(bytes % 2 == 0)
    {
    if(bytes >= 2)
    {
	    detail::_radix<T>(0, array, temp, size, bytef);
	    detail::_radix<T>(1, temp, array, size, bytef);
    }
    if(bytes >= 4)
    {
        detail::_radix<T>(2, array, temp, size, bytef);
	    detail::_radix<T>(3, temp, array, size, bytef);
    }
    if(bytes >= 6)
    {
        detail::_radix<T>(4, array, temp, size, bytef);
	    detail::_radix<T>(5, temp, array, size, bytef);
    }
    if(bytes >= 8)
    {
	    detail::_radix<T>(6, array, temp, size, bytef);
	    detail::_radix<T>(7, temp, array, size, bytef);
    }
    if(bytes >= 10)
    {
        detail::_radix<T>(8, array, temp, size, bytef);
	    detail::_radix<T>(9, temp, array, size, bytef);
    }
    if(bytes >= 12)
    {
	    detail::_radix<T>(10, array, temp, size, bytef);
	    detail::_radix<T>(11, temp, array, size, bytef);
    }
    if(bytes >= 14)
    {
        detail::_radix<T>(12, array, temp, size, bytef);
	    detail::_radix<T>(13, temp, array, size, bytef);
    }
    if(bytes >= 16)
    {
       	detail::_radix<T>(14, array, temp, size, bytef);
	    detail::_radix<T>(15, temp, array, size, bytef);
    }
    if(bytes >= 18)
    {
        detail::_radix<T>(16, array, temp, size, bytef);
	    detail::_radix<T>(17, temp, array, size, bytef);
    }
    if(bytes == 20)
    {
        detail::_radix<T>(18, array, temp, size, bytef);
	    detail::_radix<T>(19, temp, array, size, bytef);
    }
    }
    else
    {
    for(int x = 0; x < bytes; x++)
        detail::_radixc<T>(x, array, temp, size, bytef);
    }
}
template<class T>
inline void radix_sort(T* array, int size, unsigned char(*bytef)(const T&, int))
{
    radix_sort(array, size, sizeof(T), bytef);
}
template<class T>
inline void r_radix_sort(T* array, int size, unsigned char(*bytef)(const T&, int))
{
    radix_sort(array, size, bytef);
    for(int x = 0; x < size >> 1; x++)
    {
        std::swap(array[x], array[size - x - 1]);
    }
}
template<class T>
inline void r_radix_sort(T* array, int size, int bytes, unsigned char(*bytef)(const T&, int))
{
    radix_sort(array, size, bytes, bytef);
    for(int x = 0; x < size >> 1; x++)
    {
        std::swap(array[x], array[size - x - 1]);
    }
}
/////////////////////////////stl containers for vector
namespace detail
{
template <class T>
void _radix(short bitsOffset, typename std::deque<T>::iterator source, typename std::deque<T>::iterator dest, int N)
{
		const int max = 256;
		unsigned int count[max];
        typename std::deque<T>::iterator temp = source;
        typename std::deque<T>::iterator end = source + N;
        unsigned int *cp;
        unsigned int s, c;
        zerocarray(count);
        for (; source != end; source++) {
                cp = count + rdigit(*source, bitsOffset);
                ++(*cp);
        }
unsigned int* ep;
        cp = count;
        ep = count + 256;
        s = 0;
        for (; cp != ep; cp++) {
                c = *cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
        }
        source = temp;
        for (; source != end; source++) {
                cp = count + rdigit(*source, bitsOffset);
                *(dest + *cp) = *source;
                ++(*cp);
		}
}
template <class T>
void _radix(short bitsOffset, typename std::deque<T>::iterator source, typename std::deque<T>::iterator dest, typename std::deque<T>::iterator end)
{
		const int max = 256;
		unsigned int count[max];
        typename std::deque<T>::iterator temp = source;
        unsigned int *cp;
        unsigned int s, c;
        zerocarray(count);
        
        for (; source != end; ++source) {
                cp = count + rdigit(*source, bitsOffset);
                ++(*cp);
        }
unsigned int* ep;
        cp = count;
        ep = count + 256;
        s = 0;
        for (; cp != ep; cp++) {
                c = *cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
        }
         source = temp;
        for (; source != end; ++source) {
                cp = count + rdigit(*source, bitsOffset);
                *(dest + *cp) = *source;
                ++(*cp);
		}
}
template<class T>
inline void _radixc(short bitsOffset, typename std::deque<T>::iterator source, typename std::deque<T>::iterator dest, int N)
{
    _radix<T>(bitsOffset, source, dest, N);
    for(int x = 0; x < N; x++, source++, dest++)
    {
        *source = *dest;
    }
}
}
template<class T>
inline void radix_sort(typename std::deque<T>::iterator array, int size, int bytes)
{
    if(bytes > 20)
    {
        if(bytes % 2 == 0)
        {
            radix_sort(array, size, bytes - 2, bytes - 1); //do the least array copy possible
            radix_sort(array, size, bytes - 2);
        }
        else
        {
            radix_sort(array, size, bytes - 1, bytes);
            radix_sort(array, size, bytes - 1);
        }
        return;
    }
    std::deque<T> tempd = std::deque<T>(size);
    typename std::deque<T>::iterator temp = tempd.begin();
    if(bytes % 2 == 0)
    {
    if(bytes >= 2)
    {
	    detail::_radix<T>(0, array, temp, size);
	    detail::_radix<T>(1, temp, array, size);
    }
    if(bytes >= 4)
    {
        detail::_radix<T>(2, array, temp, size);
	    detail::_radix<T>(3, temp, array, size);
    }
    if(bytes >= 6)
    {
        detail::_radix<T>(4, array, temp, size);
	    detail::_radix<T>(5, temp, array, size);
    }
    if(bytes >= 8)
    {
	    detail::_radix<T>(6, array, temp, size);
	    detail::_radix<T>(7, temp, array, size);
    }
    if(bytes >= 10)
    {
        detail::_radix<T>(8, array, temp, size);
	    detail::_radix<T>(9, temp, array, size);
    }
    if(bytes >= 12)
    {
	    detail::_radix<T>(10, array, temp, size);
	    detail::_radix<T>(11, temp, array, size);
    }
    if(bytes >= 14)
    {
        detail::_radix<T>(12, array, temp, size);
	    detail::_radix<T>(13, temp, array, size);
    }
    if(bytes >= 16)
    {
       	detail::_radix<T>(14, array, temp, size);
	    detail::_radix<T>(15, temp, array, size);
    }
    if(bytes >= 18)
    {
        detail::_radix<T>(16, array, temp, size);
	    detail::_radix<T>(17, temp, array, size);
    }
    if(bytes == 20)
    {
        detail::_radix<T>(18, array, temp, size);
	    detail::_radix<T>(19, temp, array, size);
    }
    }
    else if(bytes == 1)
    {
        detail::_radixc<T>(0, array, temp, size);
    }
    else
    {
        radix_sort<T>(array, size, bytes - 1);
        detail::_radixc<T>(bytes - 1, array, temp, size);
    }
}
//////////////////////////////////////////////////////////////////user-defined function for stl
namespace detail
{
template <class T>
void _radix(short bitsOffset, typename std::deque<T>::iterator source, typename std::deque<T>::iterator dest, int N, unsigned char(*bytef)(const T&, int))
{
		const int max = 256;
		unsigned int count[max];
        unsigned int *cp;
        unsigned int s, c;
        typename std::deque<T>::iterator end = source + N;
        zerocarray(count);
        typename std::deque<T>::iterator temp = source;
        for (; source != end; source++) {
                cp = count + bytef(*source, bitsOffset);
                ++(*cp);
        }
unsigned int* ep;
        cp = count;
        ep = count + 256;
        s = 0;
        for (; cp != ep; cp++) {
                c = *cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
        }
        source = temp;
        for (; source != end; source++) {
                cp = count + bytef(*source, bitsOffset);
                dest[*cp] = *source;
                ++(*cp);
		}
}
template <class T>
void _radix(short bitsOffset, typename std::deque<T>::iterator source, typename std::deque<T>::iterator dest, typename std::deque<T>::iterator end, unsigned char(*bytef)(const T&, int))
{
		const int max = 256;
		unsigned int count[max];
        unsigned int *cp;
        unsigned int s, c, i;
        zerocarray(count);
        typename std::deque<T>::iterator temp = source;
        for (; source != end; ++source) {
                cp = count + bytef(*source, bitsOffset);
                ++(*cp);
        }
unsigned int* ep;
        cp = count;
        ep = count + 256;
        s = 0;
        for (; cp != ep; cp++) {
                c = *cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
        }
        source = temp;
        for (; source != end; ++source) {
                cp = count + bytef(*source, bitsOffset);
                dest[*cp] = *source;
                ++(*cp);
		}
}
template<class T>
inline void _radixc(short bitsOffset, typename std::deque<T>::iterator source, typename std::deque<T>::iterator dest, int N, unsigned char(*bytef)(const T&, int))
{
    _radix<T>(bitsOffset, source, dest, N, bytef);
    for(int x = 0; x < N; x++, source++, dest++)
    {
        *source = *dest;
    }
}
}
template<class T>
inline void radix_sort(typename std::deque<T>::iterator array, int size, int bytes, unsigned char(*bytef)(const T&, int))
{
    if(bytes > 20)
    {
        if(bytes % 2 == 0)
        {
            radix_sort(array, size, bytes - 1, bytes, bytef); //do the least array copy possible
            radix_sort(array, size, bytes - 2, bytef);
        }
        else
        {
            radix_sort(array, size, bytes, bytes, bytef);
            radix_sort(array, size, bytes - 1, bytef);
        }
        return;
    }
    std::deque<T> tempd = std::deque<T>(size);
    typename std::deque<T>::iterator temp = tempd.begin();
    if(bytes % 2 == 0)
    {
    if(bytes >= 2)
    {
	    detail::_radix<T>(0, array, temp, size, bytef);
	    detail::_radix<T>(1, temp, array, size, bytef);
    }
    if(bytes >= 4)
    {
        detail::_radix<T>(2, array, temp, size, bytef);
	    detail::_radix<T>(3, temp, array, size, bytef);
    }
    if(bytes >= 6)
    {
        detail::_radix<T>(4, array, temp, size, bytef);
	    detail::_radix<T>(5, temp, array, size, bytef);
    }
    if(bytes >= 8)
    {
	    detail::_radix<T>(6, array, temp, size, bytef);
	    detail::_radix<T>(7, temp, array, size, bytef);
    }
    if(bytes >= 10)
    {
        detail::_radix<T>(8, array, temp, size, bytef);
	    detail::_radix<T>(9, temp, array, size, bytef);
    }
    if(bytes >= 12)
    {
	    detail::_radix<T>(10, array, temp, size, bytef);
	    detail::_radix<T>(11, temp, array, size, bytef);
    }
    if(bytes >= 14)
    {
        detail::_radix<T>(12, array, temp, size, bytef);
	    detail::_radix<T>(13, temp, array, size, bytef);
    }
    if(bytes >= 16)
    {
       	detail::_radix<T>(14, array, temp, size, bytef);
	    detail::_radix<T>(15, temp, array, size, bytef);
    }
    if(bytes >= 18)
    {
        detail::_radix<T>(16, array, temp, size, bytef);
	    detail::_radix<T>(17, temp, array, size, bytef);
    }
    if(bytes == 20)
    {
        detail::_radix<T>(18, array, temp, size, bytef);
	    detail::_radix<T>(19, temp, array, size, bytef);
    }
    }
    else if(bytes == 1)
    {
        detail::_radixc<T>(0, array, temp, size, bytef);
    }
    else
    {
        radix_sort<T>(array, size, bytes - 1, bytef);
        detail::_radixc<T>(bytes - 1, array, temp, size, bytef);
    }
}
template<class T>
inline void radix_sort(typename std::deque<T>::iterator array, int size, unsigned char(*bytef)(const T&, int))
{
    radix_sort(array, size, sizeof(T), bytef);
}
template<class T>
inline void r_radix_sort(typename std::deque<T>::iterator array, int size, unsigned char(*bytef)(const T&, int))
{
    radix_sort<T>(array, size, bytef);
    for(int x = 0; x < size >> 1; x++)
    {
        std::swap(*(array + x), *(array + size - x - 1));
    }
}
template<class T>
inline void r_radix_sort(typename std::deque<T>::iterator array, int size, int bytes, unsigned char(*bytef)(const T&, int))
{
    radix_sort(array, size, bytes, bytef);
    for(int x = 0; x < size >> 1; x++)
    {
        std::swap(array[x], array[size - x - 1]);
    }
}
///////////////////////////////////////////////variable byte stl
template<class T>
inline void radix_sort(typename std::deque<T>::iterator a, int size, int sbyte, int ebyte)
{
    std::deque<T> tempv = std::deque<T>(size);
    typename std::deque<T>::iterator temp = tempv.begin();
    for(int x = sbyte; x < ebyte; x++)
    {
        detail::_radixc<T>(x, a, temp, size);
    }
}
template<class T>
inline void r_radix_sort(typename std::deque<T>::iterator a, int size, int sbyte, int ebyte)
{
    std::deque<T> tempv = std::deque<T>(size);
    typename std::deque<T>::iterator temp = tempv.begin();
    for(int x = sbyte; x < ebyte; x++)
    {
        detail::_radixc<T>(x, a, temp, size);
    }
    for(int x = 0; x < size >> 1; x++)
        std::swap(*(a + x), *(a + size - x - 1));
}
////////////////////////////////////////
////////////////////////////////////////generic iterator
////////////////////////////////////////
namespace detail
{
template <class Itit, class T>
void _radix(short bitsOffset, Itit& source, Itit& dest, int N)
{
		const int max = 256;
		unsigned int count[max];
        unsigned int *cp;
        unsigned int s, c, i;
        zerocarray(count);
        for (; i > 0; --i) {
                cp = count + rdigit(source[i], bitsOffset);
                ++(*cp);
        }
        i = N;
unsigned int* ep;
        cp = count;
        ep = count + 256;
        s = 0;
        for (; cp != ep; cp++) {
                c = *cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
        }
        for (; i > 0; --i) {
                cp = count + rdigit(source[i], bitsOffset);
                *(dest + *cp) = source[i];
                ++(*cp);
		}
}
template<class Itit, class T>
inline void _radixc(short bitsOffset, Itit& source, Itit& dest, int N)
{
    _radix<Itit, T>(bitsOffset, source, dest, N);
    for(int x = 0; x < N; x++)
    {
        source[x] = dest[x];
    }
}
}
template<class Itit, class T>
inline void radix_sort(Itit& array, int size, int bytes)
{
    if(bytes > 20)
    {
        if(bytes % 2 == 0)
        {
            radix_sort(array, size, bytes - 2, bytes - 1); //do the least array copy possible
            radix_sort(array, size, bytes - 2);
        }
        else
        {
            radix_sort(array, size, bytes - 1, bytes);
            radix_sort(array, size, bytes - 1);
        }
        return;
    }
    Itit temp = Itit(size);
    if(bytes % 2 == 0)
    {
    if(bytes >= 2)
    {
	    detail::_radix<T>(0, array, temp, size);
	    detail::_radix<T>(1, temp, array, size);
    }
    if(bytes >= 4)
    {
        detail::_radix<T>(2, array, temp, size);
	    detail::_radix<T>(3, temp, array, size);
    }
    if(bytes >= 6)
    {
        detail::_radix<T>(4, array, temp, size);
	    detail::_radix<T>(5, temp, array, size);
    }
    if(bytes >= 8)
    {
	    detail::_radix<T>(6, array, temp, size);
	    detail::_radix<T>(7, temp, array, size);
    }
    if(bytes >= 10)
    {
        detail::_radix<T>(8, array, temp, size);
	    detail::_radix<T>(9, temp, array, size);
    }
    if(bytes >= 12)
    {
	    detail::_radix<T>(10, array, temp, size);
	    detail::_radix<T>(11, temp, array, size);
    }
    if(bytes >= 14)
    {
        detail::_radix<T>(12, array, temp, size);
	    detail::_radix<T>(13, temp, array, size);
    }
    if(bytes >= 16)
    {
       	detail::_radix<T>(14, array, temp, size);
	    detail::_radix<T>(15, temp, array, size);
    }
    if(bytes >= 18)
    {
        detail::_radix<T>(16, array, temp, size);
	    detail::_radix<T>(17, temp, array, size);
    }
    if(bytes == 20)
    {
        detail::_radix<T>(18, array, temp, size);
	    detail::_radix<T>(19, temp, array, size);
    }
    }
    else if(bytes == 1)
    {
        detail::_radixc<T>(0, array, temp, size);
    }
    else
    {
        radix_sort<T>(array, size, bytes - 1);
        detail::_radixc<T>(bytes - 1, array, temp, size);
    }
}
//////////////////////////////////////////////////////////////////user-defined function for generic iterator
namespace detail
{
template <class Itit, class T>
void _radix(short bitsOffset, Itit& source, Itit& dest, int N, unsigned char(*bytef)(const T&, int))
{
		const int max = 256;
		unsigned int count[max];
        unsigned int *cp;
        unsigned int s, c, i;
        i = N;
        zerocarray(count);
        for (; i > 0; --i) {
                cp = count + bytef(source[i], bitsOffset);
                ++(*cp);
        }
        i = N;
unsigned int* ep;
        cp = count;
        ep = count + 256;
        s = 0;
        for (; cp != ep; cp++) {
                c = *cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
                c = *++cp;
                *cp = s;
                s += c;
        }
        for (; i > 0; --i) {
                cp = count + bytef(source[i], bitsOffset);
                dest[*cp] = source[i];
                ++(*cp);
		}
}
template<class Itit, class T>
inline void _radixc(short bitsOffset, Itit& source, Itit& dest, int N, unsigned char(*bytef)(const T&, int))
{
    _radix<Itit, T>(bitsOffset, source, dest, N, bytef);
    for(int x = 0; x < N; x++)
    {
        source[x] = dest[x];
    }
}
}
template<class Itit, class T>
inline void radix_sort(Itit& array, int size, int bytes, unsigned char(*bytef)(const T&, int))
{
    if(bytes > 20)
    {
        if(bytes % 2 == 0)
        {
            radix_sort(array, size, bytes - 1, bytes, bytef); //do the least array copy possible
            radix_sort(array, size, bytes - 2, bytef);
        }
        else
        {
            radix_sort(array, size, bytes, bytes, bytef);
            radix_sort(array, size, bytes - 1, bytef);
        }
        return;
    }
    Itit temp = Itit(size);
    if(bytes % 2 == 0)
    {
    if(bytes >= 2)
    {
	    detail::_radix<T>(0, array, temp, size, bytef);
	    detail::_radix<T>(1, temp, array, size, bytef);
    }
    if(bytes >= 4)
    {
        detail::_radix<T>(2, array, temp, size, bytef);
	    detail::_radix<T>(3, temp, array, size, bytef);
    }
    if(bytes >= 6)
    {
        detail::_radix<T>(4, array, temp, size, bytef);
	    detail::_radix<T>(5, temp, array, size, bytef);
    }
    if(bytes >= 8)
    {
	    detail::_radix<T>(6, array, temp, size, bytef);
	    detail::_radix<T>(7, temp, array, size, bytef);
    }
    if(bytes >= 10)
    {
        detail::_radix<T>(8, array, temp, size, bytef);
	    detail::_radix<T>(9, temp, array, size, bytef);
    }
    if(bytes >= 12)
    {
	    detail::_radix<T>(10, array, temp, size, bytef);
	    detail::_radix<T>(11, temp, array, size, bytef);
    }
    if(bytes >= 14)
    {
        detail::_radix<T>(12, array, temp, size, bytef);
	    detail::_radix<T>(13, temp, array, size, bytef);
    }
    if(bytes >= 16)
    {
       	detail::_radix<T>(14, array, temp, size, bytef);
	    detail::_radix<T>(15, temp, array, size, bytef);
    }
    if(bytes >= 18)
    {
        detail::_radix<T>(16, array, temp, size, bytef);
	    detail::_radix<T>(17, temp, array, size, bytef);
    }
    if(bytes == 20)
    {
        detail::_radix<T>(18, array, temp, size, bytef);
	    detail::_radix<T>(19, temp, array, size, bytef);
    }
    }
    else if(bytes == 1)
    {
        detail::_radixc<T>(0, array, temp, size, bytef);
    }
    else
    {
        radix_sort<T>(array, size, bytes - 1, bytef);
        detail::_radixc<T>(bytes - 1, array, temp, size, bytef);
    }
}
template<class Itit, class T>
inline void radix_sort(Itit& array, int size, unsigned char(*bytef)(const T&, int))
{
    radix_sort<Itit, T>(array, size, sizeof(T), bytef);
}
template<class Itit, class T>
inline void r_radix_sort(Itit& array, int size, unsigned char(*bytef)(const T&, int))
{
    radix_sort<Itit, T>(array, size, bytef);
    for(int x = 0; x < size >> 1; x++)
    {
        std::swap(array[x], array[size - x - 1]);
    }
}
template<class Itit, class T>
inline void r_radix_sort(Itit& array, int size, int bytes, unsigned char(*bytef)(const T&, int))
{
    radix_sort<Itit, T>(array, size, bytes, bytef);
    for(int x = 0; x < size >> 1; x++)
    {
        std::swap(array[x], array[size - x - 1]);
    }
}
///////////////////////////////////////////////variable byte stl
template<class Itit, class T>
inline void radix_sort(Itit& a, int size, int sbyte, int ebyte)
{
    Itit temp = Itit(size);
    for(int x = sbyte; x < ebyte; x++)
    {
        detail::_radixc<Itit, T>(x, a, temp, size);
    }
}
template<class Itit, class T>
inline void r_radix_sort(Itit& a, int size, int sbyte, int ebyte)
{
    Itit temp = Itit(size);
    for(int x = sbyte; x < ebyte; x++)
    {
        detail::_radixc<Itit, T>(x, a, temp, size);
    }
    for(int x = 0; x < size >> 1; x++)
        std::swap(a[x], a[size - x - 1]);
}
}
#endif
