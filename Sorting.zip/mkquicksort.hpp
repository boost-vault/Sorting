//include file for multikey quicksort
#ifndef BOOST_MULTIKEY_QUICKSORT_HPP
#define BOOST_MULTIKEY_QUICKSORT_HPP
#include <deque>
namespace boost
{
	namespace detail
	{
        template<typename Itit, typename KeyHolds, typename Key>
        void mkquicksort(Itit a, int l, int r, int bit, const KeyHolds& term)
        {
            if(r <= l) return;
            int i = l - 1, j = r, d = bit; const KeyHolds v = a[j][d];
            int p = i;
            int q = r;
            while(i < j)
            {
                while(a[++i][d] < v) ;
                while(v < a[--j][d]) if(j == l) break;
                if(i > j) break;
                std::swap(a[i], a[j]);
                if(a[i][d] == v) {++p; std::swap(a[p], a[i]);}
                if(a[j][d] == v) {--q; std::swap(a[q], a[j]);}
            }
            if(p == q)
            {
                 if(!(v == term)) mkquicksort<Itit, KeyHolds, Key>(a, l, r, d + 1, term);
                 return;
            }
            int k = l;
            if(a[i][d] < v) ++i;
            for(; k <= p; j--, k++) std::swap(a[k], a[j]);
            for(k = r; k >= q; i++, k--) std::swap(a[k], a[i]);
            mkquicksort<Itit, KeyHolds, Key>(a, l, j, d, term);
            if((i == r) && (a[i][d] == v)) ++i;
            if(!(v == term)) mkquicksort<Itit, KeyHolds, Key>(a, j + 1, i - 1, d + 1, term);
            mkquicksort<Itit, KeyHolds, Key>(a, i, r, d, term);
        }
        //////////////////
        template<typename Itit, typename KeyHolds, typename Key>
        void  rmkquicksort(Itit a, int l, int r, int bit, const KeyHolds& term)
        {
            if(r <= l) return;
            int i = l - 1, j = r, d = bit; const KeyHolds v = a[j][d];
            int p = i;
            int q = r;
            while(i < j)
            {
                while(v < a[++i][d]) ;
                while(a[--j][d] < v) if(j == l) break;
                if(i > j) break;
                std::swap(a[i], a[j]);
                if(a[i][d] == v) {++p; std::swap(a[p], a[i]);}
                if(a[j][d] == v) {--q; std::swap(a[q], a[j]);}
            }
            if(p == q)
            {
                 if(!(v == term)) rmkquicksort(a, l, r, d + 1, term);
                 return;
            }
            int k = l;
            if(v < a[i][d]) ++i;
            for( ; k <= p; j--, k++) std::swap(a[k], a[j]);
            for(k = r; k >= q; i++, k--) std::swap(a[k], a[i]);
            rmkquicksort(a, l, j, d, term);
            if((i == r) && (a[i][d] == v)) ++i;
            if(!(v == term)) rmkquicksort(a, j + 1, i - 1, d + 1, term);
            rmkquicksort(a, i, r, d, term);
        }
    }
	template<typename Itit, typename KeyHolds, typename Key>
	inline void mk_qsort(Itit data, int size, const KeyHolds term) //normal
	{
		detail::mkquicksort<Itit, KeyHolds, Key>(data, 0, size, 0, term);
	}
    template<typename Itit, typename KeyHolds, typename Key>
    inline void r_mk_qsort(Itit data, int size, const KeyHolds term) //reverse
    {
        detail::rmkquicksort<Itit, KeyHolds, Key>(data, 0, size, 0, term);
    }
    /////////////////////////user-defined functions
    namespace detail
	{
        template<typename Itit, typename KeyHolds, typename Key>
        void  mkquicksort(Itit a, int l, int r, int bit, const KeyHolds& term, const KeyHolds& (*keyfunc)(const Key&, int))
        {
            if(r <= l) return;
             int i = l - 1, j = r, d = bit; const KeyHolds v = keyfunc(a[j], d);
            int p = i;
            int q = r;
            while(i < j)
            {
                while(keyfunc(a[++i], d) < v) ;
                while(v < keyfunc(a[--j], d)) if(j == l) break;
                if(i > j) break;
                std::swap(a[i], a[j]);
                if(keyfunc(a[i], d) == v) {++p; std::swap(a[p], a[i]);}
                if(keyfunc(a[j], d) == v) {--q; std::swap(a[q], a[j]);}
            }
            if(p == q)
            {
                 if(!(v == term)) mkquicksort(a, l, r, d + 1, term, keyfunc);
                 return;
            }
            int k = l;
            if(keyfunc(a[i], d) < v) ++i;
            for( ; k <= p; j--, k++) std::swap(a[k], a[j]);
            for(k = r; k >= q; i++, k--) std::swap(a[k], a[i]);
            mkquicksort(a, l, j, d, keyfunc);
            if((i == r) && (keyfunc(a[i], d) == v)) ++i;
            if(!(v == term)) mkquicksort(a, j + 1, i - 1, d + 1, term, keyfunc);
            mkquicksort(a, i, r, d, term, keyfunc);
        }
        template<typename Itit, typename KeyHolds, typename Key>
        void  rmkquicksort(Itit a, int l, int r, int bit, const KeyHolds& term, const KeyHolds& (*keyfunc)(const Key&, int))
        {
            if(r <= l) return;
             int i = l - 1, j = r, d = bit; const KeyHolds v = keyfunc(a[j], d);
            int p = i;
            int q = r;
            while(i < j)
            {
                while(v < keyfunc(a[++i], d)) ;
                while(keyfunc(a[--j], d) < v) if(j == l) break;
                if(i > j) break;
                std::swap(a[i], a[j]);
                if(keyfunc(a[i], d) == v) {++p; std::swap(a[p], a[i]);}
                if(keyfunc(a[j], d) == v) {--q; std::swap(a[q], a[j]);}
            }
            if(p == q)
            {
                 if(!(v == term)) rmkquicksort(a, l, r, d + 1, term, keyfunc);
                 return;
            }
            int k = l;
            if(v < keyfunc(a[i], d)) ++i;
            for( ; k <= p; j--, k++) std::swap(a[k], a[j]);
            for(k = r; k >= q; i++, k--) std::swap(a[k], a[i]);
            rmkquicksort(a, l, j, d, term, keyfunc);
            if((i == r) && (keyfunc(a[i], d) == v)) ++i;
            if(!(v == term)) rmkquicksort(a, j + 1, i - 1, d + 1, term, keyfunc);
            rmkquicksort(a, i, r, d, term, keyfunc);
        }
    }
	template<typename Itit, typename KeyHolds, typename Key>
	inline void mk_qsort(Itit data, int size, const KeyHolds term, const KeyHolds& (*keyfunc)(const Key&, int)) //normal
	{
		detail::mkquicksort<Itit, KeyHolds, Key>(data, 0, size, 0, term, keyfunc);
	}
    template<typename Itit, typename KeyHolds, typename Key>
    inline void r_radix_qsort(Itit data, int size, const KeyHolds term, const KeyHolds& (*keyfunc)(const Key&, int)) //reverse
    {
        detail::rmkquicksort<Itit, KeyHolds, Key>(data, 0, size, 0, keyfunc);
    }
    //////////////////////////////////////////////////////////////////////////variable bytes
    template<typename Itit, typename KeyHolds, typename Key>
    inline void mk_qsort(Itit a, int size, int startbyte, const KeyHolds term)
    {
        detail::mkquicksort<Itit, KeyHolds, Key>(a, 0, size, startbyte, term);
    }
    template<typename Itit, typename KeyHolds, typename Key>
    inline void r_mk_qsort(Itit a, int start, int size, int startbyte, const KeyHolds term)
    {
        detail::rmkquicksort<Itit, KeyHolds, Key>(a, start, size, startbyte, term);
    }
    template<typename Itit, typename KeyHolds, typename Key>
    inline void mk_qsort(Itit a, int size, int startbyte, const KeyHolds term, const KeyHolds (*keyfunc)(const Key&, int))
    {
        detail::mkquicksort<Itit, KeyHolds, Key>(a, 0, size, startbyte, 1, term, keyfunc);
    }
    
    template<typename Itit, typename KeyHolds, typename Key>
    inline void mk_qsort(Itit a, int start, int size, int startbyte, const KeyHolds term, const KeyHolds& (*keyfunc)(const Key&, int))
    {
        detail::mkquicksort<Itit, KeyHolds, Key>(a, start, size, startbyte, term, keyfunc);
    }
    ////////////////////////////////////////////////////////////stl iterator
    /////////////////////////user-defined functions
    //////////////////////////////////////////////////////////////////////////variable bytes
    template<typename Itit, typename KeyHolds, typename Key>
    inline void mk_qsort(Itit a, int start, int size, int startbyte, const KeyHolds term)
    {
        detail::mkquicksort<Itit, KeyHolds, Key>(a, start, size, startbyte, term);
    }
     template<typename Itit, typename KeyHolds, typename Key>
    inline void mk_qsort(Itit a, int size, int startbyte, const KeyHolds term, const KeyHolds& (*keyfunc)(const Key&, int d))
    {
        detail::mkquicksort<Itit, KeyHolds, Key>(a, 0, size, startbyte, term, keyfunc);
    }
    //////////////////////////revers variable bytes
     template<typename Itit, typename KeyHolds, typename Key>
    inline void r_mk_qsort(Itit a, int size, int startbyte, const KeyHolds term, const KeyHolds& (*keyfunc)(const Key&, int d))
    {
        detail::rmkquicksort<Itit, KeyHolds, Key>(a, 0, size, startbyte, term, keyfunc);
    }
    template<typename Itit, typename KeyHolds, typename Key>
    inline void r_mk_qsort(Itit a, int start, int size, int startbyte, const KeyHolds term, const KeyHolds& (*keyfunc)(const Key&, int d))
    {
        detail::rmkquicksort<Itit, KeyHolds, Key>(a, start, size, startbyte, term, keyfunc);
    }
}
#endif
