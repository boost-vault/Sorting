// Rquicksort example.cpp : Defines the entry point for the console application.
//
#include <rquicksort.hpp>
#include <iostream>
#include <cstring>
using namespace std;
struct person
{
    char* name;
    int number;
    double fnum;
    char idstring_qs[30]; //this could actually be called anything, but if it is called idstring_qs, the user does not need to pass radix quicksort a function to get the values out of the string.
    person(){}
    person(int x, char* y, char* z, double w)
    {
        number = x;
        name = y;
        strcpy(idstring_qs, z);
        fnum = w;
    }
    inline int operator<(const person& a)
    {
        return strcmp(idstring_qs, a.idstring_qs) & 0x80000000;
    }
};
double fnumbers[] = {0.9, 2.1, 0.9, 5.7, 6.6}; //one set of same flaots
int numbers[] = {3, 5, 4, 1, 8}; //no same numbers
char* names[] = {"radix", "quick", "radix", "quick", "program"}; //2 sets of equal strings
int main(int argc, char* argv[])
{
    char id[30];
    person people[5];
    for(int x = 0; x < 5; x++)
    {
        boost::create_id_string("%s%e%d", id, names[x], fnumbers[x], numbers[x]); //%s means string, %d means int, and %e means double
        people[x] = person(numbers[x], names[x], id, fnumbers[x]);
    }
    boost::radix_qsort(people, 4);
    for(int x = 0; x < 5; x++)
    {
        cout << people[x].name << " has floating point value " << people[x].fnum  << " and is #" << people[x].number << ". ";
    }
	return 0;
}

