//include file for radix sorts
#ifndef BOOST_RADIX_SORT_HPP
#define BOOST_RADIX_SORT_HPP
#include <algorithm> //for swap
#include <vector>
#ifdef BOOST_USE_SSE
#ifndef BOOST_SSE_INCLUDE_FILE
#define BOOST_SSE_INCLUDE_FILE <xmmintrin.h>
#endif
#include BOOST_SSE_INCLUDE_FILE	// for prefetch
#define pfval	64
#define pfval2	128
#define pf(x)	_mm_prefetch(cpointer(x + i + pfval), 0)
#define pf2(x)	_mm_prefetch(cpointer(x + i + pfval2), 0)
void zerocarray(unsigned int* a)
{
    __m128* p = (__m128*)a;
    for(int x = 0; x < 256 >> 2; x++, p++)
    {
        *p = _mm_setzero_ps();
    }
}
#else
#define pf(x)
#define pf2(x)
void zerocarray(unsigned int* a)
{
    for(int x = 0; x < 256; x++, a++)
        *a = 0;
}
#endif
namespace boost
{
namespace detail
{
	typedef long int32;
	typedef unsigned long uint32;
	typedef float real32;
	typedef double real64;
	typedef unsigned char uint8;
	typedef const char *cpointer;
	inline uint32 _0(uint32 x)
	{
		return x & 0x7ff;
	}
	inline uint32 _1(uint32 x)
	{
		return x >> 11 & 0x7ff;
	}
	inline uint32 _2(uint32 x)
	{
		return x >> 22;
	}
// ================================================================================================
// flip a float for sorting
//  finds SIGN of fp number.
//  if it's 1 (negative float), it flips all bits
//  if it's 0 (positive float), it flips the sign only
// ================================================================================================
inline uint32 FloatFlip(uint32 f)
{
	uint32 mask = -int32(f >> 31) | 0x80000000;
	return f ^ mask;
}
inline void FloatFlipX(uint32 &f)
{
	uint32 mask = -int32(f >> 31) | 0x80000000;
	f ^= mask;
}
// ================================================================================================
// flip a float back (invert FloatFlip)
//  signed was flipped from above, so:
//  if sign is 1 (negative), it flips the sign bit back
//  if sign is 0 (positive), it flips all bits back
// ================================================================================================
inline uint32 IFloatFlip(uint32 f)
{
	uint32 mask = ((f >> 31) - 1) | 0x80000000;
	return f ^ mask;
}
void floatradix(real32 *farray, real32 *sorted, uint32 elements)
{
	uint32 i;
	uint32 *sort = (uint32*)sorted;
	uint32 *array = (uint32*)farray;
	const uint32 kHist = 2048;
	uint32 b0[kHist * 3];

	uint32 *b1 = b0 + kHist;
	uint32 *b2 = b1 + kHist;

	for (i = 0; i < kHist * 3; i++) {
		b0[i] = 0;
	}
	for (i = 0; i < elements; i++) {
		
		pf(array);

		uint32 fi = FloatFlip((uint32&)array[i]);

		++b0[_0(fi)];
		++b1[_1(fi)];
		++b2[_2(fi)];
	}
	{
		uint32 sum0 = 0, sum1 = 0, sum2 = 0;
		uint32 tsum;
		for (i = 0; i < kHist; i++) {

			tsum = b0[i] + sum0;
			b0[i] = sum0 - 1;
			sum0 = tsum;

			tsum = b1[i] + sum1;
			b1[i] = sum1 - 1;
			sum1 = tsum;

			tsum = b2[i] + sum2;
			b2[i] = sum2 - 1;
			sum2 = tsum;
		}
	}
	for (i = 0; i < elements; i++) {

		uint32 fi = array[i];
		FloatFlipX(fi);
		uint32 pos = _0(fi);
		
		pf2(array);
		sort[++b0[pos]] = fi;
	}

	for (i = 0; i < elements; i++) {
		uint32 si = sort[i];
		uint32 pos = _1(si);
		pf2(sort);
		array[++b1[pos]] = si;
	}

	for (i = 0; i < elements; i++) {
		uint32 ai = array[i];
		uint32 pos = _2(ai);
		pf2(array);
		sort[++b2[pos]] = IFloatFlip(ai);
	}
}
template<class T>
inline unsigned char rdigit(const T& num, int d)
{
    return num[d];
}
template<>
inline unsigned char rdigit(const int& num, int d)
{
    return ((unsigned char*)&num)[d];
}
template<>
inline unsigned char rdigit<long>(const long& num, int d)
{
    return ((unsigned char*)&num)[d];
}
template<>
inline unsigned char rdigit<long long>(const long long& num, int d)
{
    return ((unsigned char*)&num)[d];
}
template<>
inline unsigned char rdigit<char>(const char& num, int d)
{
    return num;
}
template<>
inline unsigned char rdigit<short>(const short& num, int d)
{
    return ((unsigned char*)&num)[d];
}
template <class T>
void _radix(short bitsOffset, T* source, T* dest, int N)
{
		const int max = 256;
		unsigned int count[max];
        register unsigned int *cp, s, c, i;
		T *sp;
        zerocarray(count);
        sp = source;
        for (i = N; i > 0; ++sp, --i) {
                cp = count + rdigit(*sp, bitsOffset);
                ++(*cp);
        }
        s = 0;
        cp = count;
        for (i = 256; i > 0; ++cp, --i) {
                c = *cp;
                *cp = s;
                s += c;
        }
        sp = source;
        for (i = N; i > 0; ++sp, --i) {
                cp = count + rdigit(*sp, bitsOffset);
                dest[*cp] = *sp;
                ++(*cp);
		}
}
template<class T>
inline void _radixc(short bitsOffset, T* source, T* dest, int N)
{
    register T* s = source;
    register T* d = dest;
    _radix<T>(bitsOffset, s, d, N);
    for(register int x = N; x > 0; *++s = *++d, --x) ; //register is a big speed increase
}
}
template<class T>
inline void radix_sort(T* array, int size, int bytes)
{
    T* temp = new T[size];
    try
    {
    if(bytes == 10)
    {
        detail::_radix<T>(9, array, temp, size);
	    detail::_radix<T>(8, temp, array, size);
       	detail::_radix<T>(7, array, temp, size);
	    detail::_radix<T>(6, temp, array, size);
	    detail::_radix<T>(5, array, temp, size);
	    detail::_radix<T>(4, temp, array, size);
        detail::_radix<T>(3, array, temp, size);
	    detail::_radix<T>(2, temp, array, size);
	    detail::_radix<T>(1, array, temp, size);
	    detail::_radix<T>(0, temp, array, size);
    }
    else if(bytes == 8)
    {
       	detail::_radix<T>(7, array, temp, size);
	    detail::_radix<T>(6, temp, array, size);
	    detail::_radix<T>(5, array, temp, size);
	    detail::_radix<T>(4, temp, array, size);
        detail::_radix<T>(3, array, temp, size);
	    detail::_radix<T>(2, temp, array, size);
	    detail::_radix<T>(1, array, temp, size);
	    detail::_radix<T>(0, temp, array, size);
    }
    else if(bytes == 6)
    {
        detail::_radix<T>(5, array, temp, size);
	    detail::_radix<T>(4, temp, array, size);
        detail::_radix<T>(3, array, temp, size);
	    detail::_radix<T>(2, temp, array, size);
	    detail::_radix<T>(1, array, temp, size);
	    detail::_radix<T>(0, temp, array, size);
    }
    else if(bytes == 4)
    {
        detail::_radix<T>(3, array, temp, size);
	    detail::_radix<T>(2, temp, array, size);
	    detail::_radix<T>(1, array, temp, size);
	    detail::_radix<T>(0, temp, array, size);
    }
    else if(bytes == 2)
    {
	    detail::_radix<T>(1, array, temp, size);
	    detail::_radix<T>(0, temp, array, size);
    }
    else
    {
    for(int x = bytes - 1; x >= 0; x--)
        detail::_radixc<T>(x, array, temp, size);
    }
    }
    catch(std::exception e)
    {
        delete temp; //so memory is always freed
        throw e; //so exception is not ignored
    }
}
template<class T>
inline void radix_sort(T* array, int size)
{
    radix_sort<T>(array, size, sizeof(T));
}
template<>
inline void radix_sort<float>(float* array, int size)
{
	float* temp = new float[size];
	detail::floatradix(array, temp, size);
	for(int x = 0; x < size; x++)
	{
		array[x] = temp[x];
	}
	delete temp;
}
template<class T>
inline void r_radix_sort(T* array, int size)
{
    radix_sort<T>(array, size);
    for(int x = 0; x < size >> 1; x++)
    {
        std::swap(array[x], array[size - x - 1]);
    }
}
template<class T>
inline void r_radix_sort(T* array, int size, int bytes)
{
    radix_sort<T>(array, size, bytes);
    for(int x = 0; x < size >> 1; x++)
    {
        std::swap(array[x], array[size - x - 1]);
    }
}
////////////////////////////////user-defined
namespace detail
{
template <class T>
void _radix(short bitsOffset, T* source, T* dest, int N, unsigned char(*bytef)(const T&, int))
{
		const int max = 256;
		unsigned int count[max];
        register unsigned int *cp, s, c, i;
		T *sp;
        zerocarray(count);
        sp = source;
        for (i = N; i > 0; ++sp, --i) {
                cp = count + bytef(*sp, bitsOffset);
                ++(*cp);
        }
        s = 0;
        cp = count;
        for (i = 256; i > 0; ++cp, --i) {
                c = *cp;
                *cp = s;
                s += c;
        }
        sp = source;
        for (i = N; i > 0; ++sp, --i) {
                cp = count + bytef(*sp, bitsOffset);
                dest[*cp] = *sp;
                ++(*cp);
		}
}
template<class T>
inline void _radixc(short bitsOffset, T* source, T* dest, int N, unsigned char(*bytef)(const T&, int))
{
    register T* s = source;
    register T* d = dest;
    _radix<T>(bitsOffset, s, d, N, bytef);
    for(register int x = N; x > 0; *++s = *++d, --x) ; //register is a big speed increase
}
}
template<class T>
inline void radix_sort(T* array, int size, int bytes, unsigned char(*bytef)(const T&, int))
{
    T* temp = new T[size];
    try
    {
    if(bytes == 10)
    {
        detail::_radix<T>(9, array, temp, size, bytef);
	    detail::_radix<T>(8, temp, array, size, bytef);
       	detail::_radix<T>(7, array, temp, size, bytef);
	    detail::_radix<T>(6, temp, array, size, bytef);
	    detail::_radix<T>(5, array, temp, size, bytef);
	    detail::_radix<T>(4, temp, array, size, bytef);
        detail::_radix<T>(3, array, temp, size, bytef);
	    detail::_radix<T>(2, temp, array, size, bytef);
	    detail::_radix<T>(1, array, temp, size, bytef);
	    detail::_radix<T>(0, temp, array, size, bytef);
    }
    else if(bytes == 8)
    {
       	detail::_radix<T>(7, array, temp, size, bytef);
	    detail::_radix<T>(6, temp, array, size, bytef);
	    detail::_radix<T>(5, array, temp, size, bytef);
	    detail::_radix<T>(4, temp, array, size, bytef);
        detail::_radix<T>(3, array, temp, size, bytef);
	    detail::_radix<T>(2, temp, array, size, bytef);
	    detail::_radix<T>(1, array, temp, size, bytef);
	    detail::_radix<T>(0, temp, array, size, bytef);
    }
    else if(bytes == 6)
    {
        detail::_radix<T>(5, array, temp, size, bytef);
	    detail::_radix<T>(4, temp, array, size, bytef);
        detail::_radix<T>(3, array, temp, size, bytef);
	    detail::_radix<T>(2, temp, array, size, bytef);
	    detail::_radix<T>(1, array, temp, size, bytef);
	    detail::_radix<T>(0, temp, array, size, bytef);
    }
    else if(bytes == 4)
    {
        detail::_radix<T>(3, array, temp, size, bytef);
	    detail::_radix<T>(2, temp, array, size, bytef);
	    detail::_radix<T>(1, array, temp, size, bytef);
	    detail::_radix<T>(0, temp, array, size, bytef);
    }
    else if(bytes == 2)
    {
	    detail::_radix<T>(1, array, temp, size, bytef);
	    detail::_radix<T>(0, temp, array, size, bytef);
    }
    else
    {
    for(int x = bytes - 1; x >= 0; x--)
        detail::_radixc<T>(x, array, temp, size, bytef);
    }
    }
    catch(std::exception e)
    {
        delete temp; //so memory is always freed
        throw e; //so exception is not ignored
    }
}
template<class T>
inline void radix_sort(T* array, int size, unsigned char(*bytef)(const T&, int))
{
    radix_sort(array, size, sizeof(T), bytef);
}
template<class T>
inline void r_radix_sort(T* array, int size, unsigned char(*bytef)(const T&, int))
{
    radix_sort(array, size, bytef);
    for(int x = 0; x < size >> 1; x++)
    {
        std::swap(array[x], array[size - x - 1]);
    }
}
template<class T>
inline void r_radix_sort(T* array, int size, int bytes, unsigned char(*bytef)(const T&, int))
{
    radix_sort(array, size, bytes, bytef);
    for(int x = 0; x < size >> 1; x++)
    {
        std::swap(array[x], array[size - x - 1]);
    }
}
/////////////////////////////stl containers for vector
namespace detail
{
template <class T>
void _radix(short bitsOffset, typename std::vector<T>::iterator source, typename std::vector<T>::iterator dest, int N)
{
		const int max = 256;
		unsigned int count[max];
        const std::vector<T>::iterator temp = source;
        register unsigned int *cp, s, c, i;
        zerocarray(count);
        for (i = N; i > 0; ++source, --i) {
                cp = count + rdigit(*source, bitsOffset);
                ++(*cp);
        }
        s = 0;
        cp = count;
        for (i = 256; i > 0; ++cp, --i) {
                c = *cp;
                *cp = s;
                s += c;
        }
        source = temp;
        for (i = N; i > 0; ++source, --i) {
                cp = count + rdigit(*source, bitsOffset);
                *(dest + *cp) = *source;
                ++(*cp);
		}
}
template<class T>
inline void _radixc(short bitsOffset, typename std::vector<T>::iterator source, typename std::vector<T>::iterator dest, int N)
{
    _radix<T>(bitsOffset, source, dest, N);
    for(register int x = N; x > 0; *++source = *++dest, --x) ; //register is a big speed increase
}
}
template<class T>
inline void radix_sort(typename std::vector<T>::iterator array, int size, int bytes)
{
    std::vector<T> tempv = std::vector<T>(size);
    std::vector<T>::iterator temp = tempv.begin();
    if(bytes == 10)
    {
        detail::_radix<T>(9, array, temp, size);
	    detail::_radix<T>(8, temp, array, size);
       	detail::_radix<T>(7, array, temp, size);
	    detail::_radix<T>(6, temp, array, size);
	    detail::_radix<T>(5, array, temp, size);
	    detail::_radix<T>(4, temp, array, size);
        detail::_radix<T>(3, array, temp, size);
	    detail::_radix<T>(2, temp, array, size);
	    detail::_radix<T>(1, array, temp, size);
	    detail::_radix<T>(0, temp, array, size);
    }
    else if(bytes == 8)
    {
       	detail::_radix<T>(7, array, temp, size);
	    detail::_radix<T>(6, temp, array, size);
	    detail::_radix<T>(5, array, temp, size);
	    detail::_radix<T>(4, temp, array, size);
        detail::_radix<T>(3, array, temp, size);
	    detail::_radix<T>(2, temp, array, size);
	    detail::_radix<T>(1, array, temp, size);
	    detail::_radix<T>(0, temp, array, size);
    }
    else if(bytes == 6)
    {
        detail::_radix<T>(5, array, temp, size);
	    detail::_radix<T>(4, temp, array, size);
        detail::_radix<T>(3, array, temp, size);
	    detail::_radix<T>(2, temp, array, size);
	    detail::_radix<T>(1, array, temp, size);
	    detail::_radix<T>(0, temp, array, size);
    }
    else if(bytes == 4)
    {
        detail::_radix<T>(3, array, temp, size);
	    detail::_radix<T>(2, temp, array, size);
	    detail::_radix<T>(1, array, temp, size);
	    detail::_radix<T>(0, temp, array, size);
    }
    else if(bytes == 2)
    {
	    detail::_radix<T>(1, array, temp, size);
	    detail::_radix<T>(0, temp, array, size);
    }
    else
    {
    for(int x = bytes - 1; x >= 0; x--)
        detail::_radixc<T>(x, array, temp, size);
    }
}
//----------------------------------------------------------------------------------------------//
//        what is the error here? msvc reports 31 errors about function parameters
/*//////////////////////////////////////////////////////////////////user-defined function for stl
namespace detail
{
template <class T>
void _radix(short bitsOffset, typename std::vector<T>::iterator source, typename std::vector<T>::iterator dest, int N, unsigned char(*bytef)(const T&, int))
{
		const int max = 256;
		unsigned int count[max];
        register unsigned int *cp, s, c, i;
        zerocarray(count);
        const std::vector<T>::iterator temp = source;
        for (i = N; i > 0; ++source, --i) {
                cp = count + bytef(*source, bitsOffset);
                ++(*cp);
        }
        s = 0;
        cp = count;
        for (i = 256; i > 0; ++cp, --i) {
                c = *cp;
                *cp = s;
                s += c;
        }
        temp;
        for (i = N; i > 0; ++source, --i) {
                cp = count + bytef(*source, bitsOffset);
                dest[*cp] = *source;
                ++(*cp);
		}
}
template<class T>
inline void _radixc(short bitsOffset, typename std::vector<T>::iterator source, typename std::vector<T>::iterator dest, int N, unsigned char(*bytef)(const T&, int))
{
    _radix<T>(bitsOffset, source, dest, N, bytef);
    for(register int x = N; x > 0; *++source = *++dest, --x) ; //register is a big speed increase
}
}
template<class T>
inline void radix_sort(typename std::vector<T>::iterator array, int size, int bytes, unsigned char(*bytef)(const T&, int))
{
    T* temp = new T[size];
    try
    {
    if(bytes == 10)
    {
        detail::_radix<T>(9, array, temp, size, bytef);
	    detail::_radix<T>(8, temp, array, size, bytef);
       	detail::_radix<T>(7, array, temp, size, bytef);
	    detail::_radix<T>(6, temp, array, size, bytef);
	    detail::_radix<T>(5, array, temp, size, bytef);
	    detail::_radix<T>(4, temp, array, size, bytef);
        detail::_radix<T>(3, array, temp, size, bytef);
	    detail::_radix<T>(2, temp, array, size, bytef);
	    detail::_radix<T>(1, array, temp, size, bytef);
	    detail::_radix<T>(0, temp, array, size, bytef);
    }
    else if(bytes == 8)
    {
       	detail::_radix<T>(7, array, temp, size, bytef);
	    detail::_radix<T>(6, temp, array, size, bytef);
	    detail::_radix<T>(5, array, temp, size, bytef);
	    detail::_radix<T>(4, temp, array, size, bytef);
        detail::_radix<T>(3, array, temp, size, bytef);
	    detail::_radix<T>(2, temp, array, size, bytef);
	    detail::_radix<T>(1, array, temp, size, bytef);
	    detail::_radix<T>(0, temp, array, size, bytef);
    }
    else if(bytes == 6)
    {
        detail::_radix<T>(5, array, temp, size, bytef);
	    detail::_radix<T>(4, temp, array, size, bytef);
        detail::_radix<T>(3, array, temp, size, bytef);
	    detail::_radix<T>(2, temp, array, size, bytef);
	    detail::_radix<T>(1, array, temp, size, bytef);
	    detail::_radix<T>(0, temp, array, size, bytef);
    }
    else if(bytes == 4)
    {
        detail::_radix<T>(3, array, temp, size, bytef);
	    detail::_radix<T>(2, temp, array, size, bytef);
	    detail::_radix<T>(1, array, temp, size, bytef);
	    detail::_radix<T>(0, temp, array, size, bytef);
    }
    else if(bytes == 2)
    {
	    detail::_radix<T>(1, array, temp, size, bytef);
	    detail::_radix<T>(0, temp, array, size, bytef);
    }
    else
    {
    for(int x = bytes - 1; x >= 0; x--)
        detail::_radixc<T>(x, array, temp, size, bytef);
    }
    }
    catch(std::exception e)
    {
        delete temp; //so memory is always freed
        throw e; //so exception is not ignored
    }
}
template<class T>
inline void radix_sort(typename std::vector<T>::iterator array, int size, unsigned char(*bytef)(const T&, int))
{
    radix_sort(array, size, sizeof(T), bytef);
}
template<class T>
inline void r_radix_sort(typename std::vector<T>::iterator array, int size, unsigned char(*bytef)(const T&, int))
{
    radix_sort<T>(array, size, bytef);
    for(int x = 0; x < size >> 1; x++)
    {
        std::swap(*(array + x), *(array + size - x - 1));
    }
}
template<class T>
inline void r_radix_sort(typename std::vector<T>::iterator array, int size, int bytes, unsigned char(*bytef)(const T&, int))
{
    radix_sort(array, size, bytes, bytef);
    for(int x = 0; x < size >> 1; x++)
    {
        std::swap(array[x], array[size - x - 1]);
    }
}*/
///////////////////////////////variable byte
template<class T>
inline void radix_sort(T* a, int size, int sbyte, int ebyte)
{
    T* temp = new T[size];
    for(int x = sbyte; x <= ebyte; x++)
    {
        detail::_radixc<T>(x, a, temp, size);
    }
}
template<class T>
inline void r_radix_sort(T* a, int size, int sbyte, int ebyte)
{
    T* temp = new T[size];
    for(int x = sbyte; x <= ebyte; x++)
    {
        detail::_radixc<T>(x, a, temp, size);
    }
    for(int x = 0; x < size >> 1; x++)
        std::swap(a[x], a[size - x - 1]);
}
template<class T>
inline void radix_sort(T* a, int size, int sbyte, int ebyte, unsigned char(*bytef)(const T&, int))
{
    T* temp = new T[size];
    for(int x = sbyte; x <= ebyte; x++)
    {
        detail::_radixc<T>(x, a, temp, size, bytef);
    }
}
template<class T>
inline void r_radix_sort(T* a, int size, int sbyte, int ebyte, unsigned char(*bytef)(const T&, int))
{
    T* temp = new T[size];
    for(int x = sbyte; x <= ebyte; x++)
    {
        detail::_radixc<T>(x, a, temp, size, bytef);
    }
    for(int x = 0; x < size >> 1; x++)
        std::swap(a[x], a[size - x - 1]);
}
///////////////////////////////////////////////variable byte stl
template<class T>
inline void radix_sort(typename std::vector<T>::iterator a, int size, int sbyte, int ebyte)
{
    std::vector<T> tempv = std::vector<T>(size);
    std::vector<T>::iterator temp = tempv.begin();
    for(int x = sbyte; x <= ebyte; x++)
    {
        detail::_radixc<T>(x, a, temp, size);
    }
}
template<class T>
inline void r_radix_sort(typename std::vector<T>::iterator a, int size, int sbyte, int ebyte)
{
    std::vector<T> tempv = std::vector<T>(size);
    std::vector<T>::iterator temp = tempv.begin();
    for(int x = sbyte; x <= ebyte; x++)
    {
        detail::_radixc<T>(x, a, temp, size);
    }
    for(int x = 0; x < size >> 1; x++)
        std::swap(*(a + x), *(a + size - x - 1));
}
/*template<class T>
inline void radix_sort(T* a, int size, int sbyte, int ebyte, unsigned char(*bytef)(const T&, int))
{
    T* temp = new T[size];
    for(int x = sbyte; x <= ebyte; x++)
    {
        detail::_radixc<T>(x, a, temp, size, bytef);
    }
}
template<class T>
inline void r_radix_sort(T* a, int size, int sbyte, int ebyte, unsigned char(*bytef)(const T&, int))
{
    T* temp = new T[size];
    for(int x = sbyte; x <= ebyte; x++)
    {
        detail::_radixc<T>(x, a, temp, size, bytef);
    }
    for(int x = 0; x < size >> 1; x++)
        std::swap(a[x], a[size - x - 1]);
}*/
}
#endif