// radixsort.cpp : Defines the entry point for the console application.
// this program sorts the class radixtest by the numbers array contained in radixtest.
//It first examines the first integer in the numbers array, then the second.
//the array test of radixtests is sorted, then outputed to the standard output.
//they will be in the proper order.
//this could also be done by an operator< and used with std::sort
//but that operator would have multiple branches
//I wrote an operator< to show why it would be slow

#include "radix.hpp"
#include <cstdlib>
#include <iostream>
#include <time.h>
class radixtest
{
public:
    int numbers[2];
    radixtest()
    {
        numbers[0] = rand() % 10;
        numbers[1] = rand() % 10;
    }
    inline unsigned char operator[](int num)
    {return ((unsigned char*)numbers)[num];}
    inline unsigned char operator[](int num) const
    {return ((unsigned char*)numbers)[num];}
    ~radixtest()
    {}
    bool operator<(const radixtest& a) const
    {
        if(numbers[0] < a.numbers[0])
        return true;
        else if(numbers[0] == a.numbers[0])
        {
            if (numbers[1] < a.numbers[1])
                return true;
        }
        return false;
    }
};
std::ostream& operator<<(std::ostream& o, radixtest& t)
{
    return o << "{" << t.numbers[0] << ", " << t.numbers[1] << "}";
}
int main(int argc, char* argv[])
{
    srand((unsigned)time(NULL));
    radixtest tests[1000];
    boost::radix_sort(tests, 1000, 8); 
    for(int x = 0; x < 999; x++)
    {
        std::cout << tests[x] << " ";
        if(tests[x + 1] < tests[x])
        {
            std::cout << "ERROR" << std::endl;
        }
    }
	return 0;
}

