#include <windows.h>

#include "Timer.h"

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//starts the timer
void MTimer::start(void)
{
 QueryPerformanceCounter(&start_ticks);
}

//---------------------------------------------------------------------------
//stops the timer and returns the time in microseconds
unsigned long MTimer::stop()
{
 unsigned long elapsed;
 LARGE_INTEGER freq;

 QueryPerformanceCounter(&stop_ticks);
 QueryPerformanceFrequency(&freq);

 elapsed = (unsigned long)(1000000*(stop_ticks.QuadPart - start_ticks.QuadPart)/freq.QuadPart);

 return elapsed;
}

//---------------------------------------------------------------------------
//wait for specified milliseconds
void MTimer::wait(unsigned long wait)
{
 unsigned long startTime = GetTickCount();

 while (GetTickCount() - startTime < wait) ;
}

//---------------------------------------------------------------------------
