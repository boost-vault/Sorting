//---------------------------------------------------------------------------
#ifndef MTimerH
#define MTimerH
#include <windows.h>
class MTimer
{
private:
 LARGE_INTEGER   start_ticks,stop_ticks;

public:
 void            start(void); //starts the timer
 unsigned long   stop();      //stops timer and return elapsed time in microseconds
 void            wait(unsigned long time); //wait for specified milliseconds
};

//---------------------------------------------------------------------------
#endif