// SortTimings.cpp : Defines the entry point for the console application.
//

#include <iostream>
#include <cstdlib>
#include <algorithm>
using namespace std;
#include <radix.hpp>
#include "Timer.h"
const int maxn = 0x7ffff;
float af[maxn];
int ai[maxn];
int _tmain(int argc, _TCHAR* argv[])
{
    MTimer timer;
    cout << "Comparison of timings between std::sort and radixsort on floats and integers\n"
         << "These results are both on random arrays, and the units are microseconds\n";
    cout << "Sorting " << maxn << " floats" << endl;
    for(int x = 0; x < maxn; x++)
    {
        af[x] = (float)rand() / rand();
    }
    timer.start();
    boost::radix_sort<float>(af, maxn);
    cout << "Radix Sort: " << timer.stop() << endl;
    for(int x = 0; x < maxn - 1; x++)
    {
        if(af[x + 1] < af[x])
        {
            cout << "ERROR" << endl;
        }
    }
    for(int x = 0; x < maxn; x++)
    {
        af[x] = (float)rand() / rand();
    }
    timer.start();
    std::sort<float*>(af, &af[maxn]);
    cout << "std::sort: " << timer.stop() << endl;
    for(int x = 0; x < maxn - 1; x++)
    {
        if(af[x + 1] < af[x])
        {
            cout << "ERROR" << endl;
        }
    }
    ///////
     cout << "Sorting " << maxn << " ints" << endl;
    for(int x = 0; x < maxn; x++)
    {
        ai[x] = rand();
    }
    timer.start();
    boost::radix_sort<int>(ai, maxn);
    cout << "Radix Sort: " << timer.stop() << endl;
    for(int x = 0; x < maxn - 1; x++)
    {
        if(ai[x + 1] < ai[x])
        {
            cout << "ERROR" << endl;
        }
    }
    for(int x = 0; x < maxn; x++)
    {
        ai[x] = rand();
    }
    timer.start();
    std::sort<int*>(ai, &ai[maxn]);
    cout << "std::sort: " << timer.stop() << endl;
    for(int x = 0; x < maxn - 1; x++)
    {
        if(ai[x + 1] < ai[x])
        {
            cout << "ERROR" << endl;
        }
    }
    return 0;
}
