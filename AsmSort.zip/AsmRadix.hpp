//header file for linkage to radix sort
namespace boost
{
    namespace detail
    {
        extern "C" void __cdecl _radix(short, int*, int*, int);
    }
    inline void radix_sort(int* array, int N)
    {
        int* temp = new int[N];
        detail::_radix(0, array, temp, N);
        detail::_radix(8, temp, array, N);
        detail::_radix(16, array, temp, N);
        detail::_radix(24, temp, array, N);
    }
}